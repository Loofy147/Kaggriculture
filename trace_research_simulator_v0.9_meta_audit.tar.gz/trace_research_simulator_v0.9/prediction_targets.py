from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, Optional, Sequence, Tuple, Any, List
import copy, math, statistics, json

from simulator import ResearchWorld, Scenario, Action, ActionType, Observation, build_greedy_trace

Pos = Tuple[int, int]

@dataclass(frozen=True)
class TraceOutcomePrediction:
    step: int
    action_kind: str
    predicted_progress: float
    predicted_cost: float
    predicted_reward: float
    uncertainty: float

@dataclass(frozen=True)
class ReachabilityPrediction:
    step: int
    horizon: int
    target: Optional[Pos]
    predicted_probability: float
    predicted_value: float
    uncertainty: float

@dataclass(frozen=True)
class TargetEvaluation:
    profile: str
    seed: int
    step: int
    horizon: int
    trace_progress_realized: float
    trace_reward_realized: float
    progress_residual: float
    reward_residual: float
    predicted_reachability: float
    oracle_reachability: float
    reachability_residual: float
    target: Optional[Pos]
    target_available_at_start: bool
    event_active: bool
    event_kinds: Tuple[str, ...]

class OnlineTracePredictor:
    """Agent-visible baseline predictor; never accesses simulator truth."""
    def __init__(self, move_cost: float = 0.25, wait_cost: float = 0.10):
        self.move_cost = move_cost
        self.wait_cost = wait_cost
        self.reward_mean = 0.0
        self.reward_var = 1.0
        self.n = 0
        self.progress_mean = 0.0
        self.progress_var = 1.0
        self.p_failure = 0.05

    @staticmethod
    def _manhattan(a: Pos, b: Pos) -> int:
        return abs(a[0]-b[0]) + abs(a[1]-b[1])

    def predict(self, obs: Observation, action: Action, target: Optional[Pos]) -> TraceOutcomePrediction:
        if target is None:
            target = action.target
        progress = 0.0
        predicted_cost = self.wait_cost if action.kind == ActionType.WAIT else self.move_cost
        predicted_reward = -predicted_cost
        uncertainty = 0.5
        if action.kind == ActionType.MOVE and action.target is not None:
            if action.target in set(obs.blocked_visible):
                progress = 0.0
                predicted_reward -= 2.0
                uncertainty = min(1.0, 0.8 + 0.15*self.p_failure)
            elif obs.agent_pos != action.target:
                next_dist = self._manhattan(obs.agent_pos, action.target) - 1
                progress = 1.0 if next_dist < self._manhattan(obs.agent_pos, action.target) else 0.0
                predicted_reward -= self.move_cost
            else:
                progress = 1.0
        elif action.kind == ActionType.COLLECT:
            visible_here = any(r.pos == obs.agent_pos and r.available for r in obs.visible_resources.values())
            progress = 1.0 if visible_here else 0.0
            predicted_reward = 10.0 * (1.0 - self.p_failure) if visible_here else -0.5
            uncertainty = 0.35 if visible_here else 0.65
        elif action.kind == ActionType.RESERVE:
            target_visible = action.target is not None and any(r.pos == action.target and r.available for r in obs.visible_resources.values())
            progress = 0.25 if target_visible else 0.0
            predicted_reward = 0.1 if target_visible else -0.5
            uncertainty = 0.4 if target_visible else 0.7
        elif action.kind == ActionType.WAIT:
            progress = 0.0
            predicted_reward = -self.wait_cost
        return TraceOutcomePrediction(obs.step, action.kind.value, progress, predicted_cost, predicted_reward, uncertainty)

    def update(self, reward: float, realized_progress: float, failed: bool) -> None:
        self.n += 1
        alpha = 1.0 / min(self.n, 50)
        if self.n == 1:
            self.reward_mean = reward
            self.progress_mean = realized_progress
        else:
            self.reward_mean = (1-alpha)*self.reward_mean + alpha*reward
            self.progress_mean = (1-alpha)*self.progress_mean + alpha*realized_progress
        residual = reward - self.reward_mean
        self.reward_var = max(1e-6, (1-alpha)*self.reward_var + alpha*residual*residual)
        pres = realized_progress - self.progress_mean
        self.progress_var = max(1e-6, (1-alpha)*self.progress_var + alpha*pres*pres)
        self.p_failure = (1-alpha)*self.p_failure + alpha*(1.0 if failed else 0.0)

    def snapshot(self) -> Dict[str, float]:
        return {
            "reward_mean": self.reward_mean,
            "reward_std": math.sqrt(self.reward_var),
            "progress_mean": self.progress_mean,
            "progress_std": math.sqrt(self.progress_var),
            "failure_rate": self.p_failure,
        }


def visible_target_candidates(obs: Observation) -> List[Pos]:
    vals = [r.pos for r in obs.visible_resources.values() if r.available]
    return sorted(set(vals), key=lambda p: abs(p[0]-obs.agent_pos[0]) + abs(p[1]-obs.agent_pos[1]))


def predict_reachability(obs: Observation, target: Optional[Pos], horizon: int, predictor: OnlineTracePredictor) -> ReachabilityPrediction:
    if target is None:
        return ReachabilityPrediction(obs.step, horizon, None, 0.0, 0.0, 1.0)
    dist = abs(target[0]-obs.agent_pos[0]) + abs(target[1]-obs.agent_pos[1])
    blocked_penalty = sum(1 for p in obs.blocked_visible if abs(p[0]-obs.agent_pos[0]) + abs(p[1]-obs.agent_pos[1]) <= dist + 1)
    visibility = any(r.pos == target and r.available for r in obs.visible_resources.values())
    failure = predictor.p_failure
    slack = horizon - dist
    base = 1.0 / (1.0 + math.exp(-0.9*(slack)))
    prob = base
    if visibility:
        prob *= 1.05
    else:
        prob *= 0.65
    prob *= max(0.05, 1.0 - 0.18*blocked_penalty)
    prob *= max(0.05, 1.0 - 0.5*failure)
    prob = min(1.0, max(0.0, prob))
    uncertainty = min(1.0, 0.25 + (0.25 if not visibility else 0.0) + 0.3*failure)
    value = prob * max(0.0, 10.0 - predictor.move_cost*dist)
    return ReachabilityPrediction(obs.step, horizon, target, prob, value, uncertainty)


def oracle_reachability(world: ResearchWorld, target: Optional[Pos], horizon: int, beam_width: int = 3) -> float:
    if target is None:
        return 0.0
    branch = copy.deepcopy(world)
    # Approximate task-level attainability from full world state for evaluation only.
    if not any(r.pos == target and r.available for r in branch.ground_truth().resources.values()):
        return 0.0
    start_pos = branch.ground_truth().agent.pos
    if target in branch.ground_truth().blocked:
        direct = 999
    else:
        direct = abs(target[0]-start_pos[0]) + abs(target[1]-start_pos[1])
    if direct <= horizon:
        base = 1.0
    else:
        base = max(0.0, 1.0 - (direct-horizon)/max(1.0,horizon+1))
    # Opponent pressure reduces probability when the target is contested.
    g = branch.ground_truth()
    if g.opponents:
        nearest = min(abs(o.pos[0]-target[0])+abs(o.pos[1]-target[1]) for o in g.opponents.values())
        base *= min(1.0, 0.35 + nearest / 8.0)
    if target in g.blocked:
        base *= 0.05
    return min(1.0, max(0.0, base))


def matched_target_evaluation(scenario: Scenario, event_kind: str, horizons: Sequence[int]=(3,5,10)) -> List[TargetEvaluation]:
    kind_alias = {"local": "local_block", "regime": "regime_change", "structural": "structural_block", "adversarial": "opponent_intercept"}
    concrete_kind = kind_alias.get(event_kind, event_kind)
    event_points = [p.start for p in scenario.perturbations if p.kind == concrete_kind]
    if not event_points:
        return []
    start = event_points[0]
    steps = range(max(0,start-2), min(scenario.config.horizon-1,start+6)+1)
    clean = copy.deepcopy(scenario)
    clean.perturbations = [p for p in clean.perturbations if p.kind != concrete_kind]
    clean_world = ResearchWorld(clean)
    pert_world = ResearchWorld(scenario)
    clean_world.reset(); pert_world.reset()
    trace = build_greedy_trace(scenario)
    pred_clean = OnlineTracePredictor(scenario.config.move_cost, scenario.config.wait_cost)
    pred_pert = OnlineTracePredictor(scenario.config.move_cost, scenario.config.wait_cost)
    out: List[TargetEvaluation] = []
    for step in range(scenario.config.horizon):
        clean_obs, pert_obs = clean_world.observe(), pert_world.observe()
        action = trace[min(step,len(trace)-1)]
        # Evaluation target is the next macro-objective remaining in the CLEAN reference world.
        # This avoids confusing pre-existing objective loss with the causal effect of the event.
        clean_truth = clean_world.ground_truth()
        target = clean_truth.goal_remaining[0] if clean_truth.goal_remaining else None
        # Evaluate only at the matched causal window and only when the clean reference
        # still has a concrete objective to assess.
        if step in steps and target is not None:
            pc = pred_clean.predict(clean_obs, action, target)
            pp = pred_pert.predict(pert_obs, action, target)
            # execute in clones for realized next-step outcome
            cw = copy.deepcopy(clean_world); pw = copy.deepcopy(pert_world)
            rc = cw.step(action); rp = pw.step(action)
            progress_c = 1.0 if rc.truth.agent.pos != clean_obs.agent_pos or rc.feedback.get("status") in {"executed","partial"} and action.kind == ActionType.COLLECT else 0.0
            progress_p = 1.0 if rp.truth.agent.pos != pert_obs.agent_pos or rp.feedback.get("status") in {"executed","partial"} and action.kind == ActionType.COLLECT else 0.0
            for h in horizons:
                prc = predict_reachability(clean_obs, target, h, pred_clean)
                prp = predict_reachability(pert_obs, target, h, pred_pert)
                orc = oracle_reachability(clean_world, target, h)
                orp = oracle_reachability(pert_world, target, h)
                active = tuple(p.kind for p in pert_world.ground_truth().perturbations if p.active(step))
                out.append(TargetEvaluation(
                    profile=event_kind, seed=scenario.seed, step=step, horizon=int(h),
                    trace_progress_realized=progress_p,
                    trace_reward_realized=float(rp.feedback.get("reward",0.0)),
                    progress_residual=progress_p-pp.predicted_progress,
                    reward_residual=float(rp.feedback.get("reward",0.0))-pp.predicted_reward,
                    predicted_reachability=prp.predicted_probability,
                    oracle_reachability=orp,
                    reachability_residual=prp.predicted_probability-orp,
                    target=target,
                    target_available_at_start=any(r.pos==target and r.available for r in pert_obs.visible_resources.values()) if target else False,
                    event_active=bool(active), event_kinds=active,
                ))
        rc = clean_world.step(action)
        rp = pert_world.step(action)
        progress_c = 1.0 if rc.truth.agent.pos != clean_obs.agent_pos or rc.feedback.get("status") in {"executed","partial"} and action.kind == ActionType.COLLECT else 0.0
        progress_p = 1.0 if rp.truth.agent.pos != pert_obs.agent_pos or rp.feedback.get("status") in {"executed","partial"} and action.kind == ActionType.COLLECT else 0.0
        pred_c = pred_clean.predict(clean_obs, action, target)
        pred_p = pred_pert.predict(pert_obs, action, target)
        pred_clean.update(float(rc.feedback.get("reward",0.0)), progress_c, not rc.feedback.get("executed",True))
        pred_pert.update(float(rp.feedback.get("reward",0.0)), progress_p, not rp.feedback.get("executed",True))
        if rc.done or rp.done:
            break
    return out


def summarize(records: Sequence[TargetEvaluation]) -> Dict[str, Any]:
    by: Dict[str, Dict[str, Any]] = {}
    profiles = sorted(set(r.profile for r in records))
    for profile in profiles:
        rr = [r for r in records if r.profile==profile]
        by_h: Dict[str, Any] = {}
        for h in sorted(set(r.horizon for r in rr)):
            x=[r for r in rr if r.horizon==h]
            by_h[str(h)] = {
                "n": len(x),
                "mean_reward_residual": statistics.mean(r.reward_residual for r in x),
                "mean_progress_residual": statistics.mean(r.progress_residual for r in x),
                "mean_reachability_residual": statistics.mean(r.reachability_residual for r in x),
                "mae_reachability": statistics.mean(abs(r.reachability_residual) for r in x),
                "oracle_reachability_mean": statistics.mean(r.oracle_reachability for r in x),
                "predicted_reachability_mean": statistics.mean(r.predicted_reachability for r in x),
                "event_active_rate": statistics.mean(1.0 if r.event_active else 0.0 for r in x),
            }
        by[profile]=by_h
    return {"profiles":by,"records":len(records)}


def save_json(path: str, payload: Any) -> None:
    with open(path,"w",encoding="utf-8") as f:
        json.dump(payload,f,indent=2,default=asdict)
