import os, sys, json, statistics
sys.path.insert(0,os.path.dirname(__file__))
from simulator import ScenarioFactory, WorldConfig, ResearchWorld
from prediction_targets import OnlineTracePredictor, oracle_reachability
from reachability_model import ReachabilityModel

def sample_rows(profile, seeds, horizon=55, H=5):
    rows=[]
    cfg=WorldConfig(horizon=horizon)
    for seed in seeds:
        sc=ScenarioFactory(cfg).make(seed,profile)
        clean=__import__('copy').deepcopy(sc)
        concrete={"local":"local_block","regime":"regime_change","structural":"structural_block","adversarial":"opponent_intercept"}[profile]
        clean.perturbations=[p for p in clean.perturbations if p.kind!=concrete]
        w=ResearchWorld(sc); cw=ResearchWorld(clean); w.reset(); cw.reset()
        model=ReachabilityModel(); pred=OnlineTracePredictor(cfg.move_cost,cfg.wait_cost)
        for step in range(horizon):
            obs=w.observe(); cobs=cw.observe()
            ct=cw.ground_truth().goal_remaining[0] if cw.ground_truth().goal_remaining else None
            if ct is not None:
                feats=model.features(obs,ct,H,pred.p_failure)
                y=oracle_reachability(cw,ct,H)
                # Binary label: reachable enough for the target within horizon.
                yb=1.0 if y>=0.5 else 0.0
                rows.append((seed,step,feats,y,yb, bool([p for p in w.ground_truth().perturbations if p.active(step)])))
            a=__import__('simulator').build_greedy_trace(sc)[min(step,len(__import__('simulator').build_greedy_trace(sc))-1)]
            r=w.step(a); cr=cw.step(a)
            pred.update(float(r.feedback.get('reward',0)), 0.0, not r.feedback.get('executed',True))
            if r.done or cr.done: break
    return rows

def fit_and_eval(train, test):
    try:
        from sklearn.linear_model import LogisticRegression
        X=[r[2] for r in train]; y=[r[4] for r in train]
        model=LogisticRegression(max_iter=500).fit(X,y)
        probs=model.predict_proba([r[2] for r in test])[:,1].tolist()
        labels=[r[4] for r in test]
        mae=statistics.mean(abs(p-y) for p,y in zip(probs,labels))
        acc=sum((p>=0.5)==bool(y) for p,y in zip(probs,labels))/len(labels)
        brier=statistics.mean((p-y)**2 for p,y in zip(probs,labels))
        return {"n_test":len(test),"mae":mae,"brier":brier,"accuracy":acc,"coef":model.coef_.tolist(),"intercept":model.intercept_.tolist()}
    except Exception as e:
        return {"error":str(e)}

all_results={}
for profile in ["local","regime","structural","adversarial"]:
    train=sample_rows(profile,range(100,110))
    test=sample_rows(profile,range(110,120))
    all_results[profile]=fit_and_eval(train,test)
print(json.dumps(all_results,indent=2))
out='/mnt/data/trace_research_simulator_v0.9/results/reachability_supervised_v0.9.json'
json.dump(all_results,open(out,'w'),indent=2)
