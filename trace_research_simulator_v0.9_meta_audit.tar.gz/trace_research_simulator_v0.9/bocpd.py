from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional
import math


@dataclass
class GaussianBOCPDConfig:
    hazard_lambda: float = 40.0
    prior_mean: float = 0.0
    prior_kappa: float = 1.0
    prior_alpha: float = 1.0
    prior_beta: float = 1.0
    max_run_length: int = 200


@dataclass
class BOCPDStep:
    t: int
    observation: float
    cp_probability: float
    most_probable_run_length: int


class GaussianBOCPD:
    """Online Bayesian change-point detector with Normal-Inverse-Gamma predictive model.

    This detector is deliberately observation-only: it must never inspect simulator truth,
    perturbation metadata, or oracle labels. It maintains a posterior over the run length.
    """

    def __init__(self, config: Optional[GaussianBOCPDConfig] = None):
        self.config = config or GaussianBOCPDConfig()
        self.reset()

    def reset(self) -> None:
        c = self.config
        # Run-length posterior for r_t = 0..max_run_length.
        self.run_probs: List[float] = [1.0]
        # Sufficient statistics per run length: (n, mean, kappa, alpha, beta)
        self.stats = [(0, c.prior_mean, c.prior_kappa, c.prior_alpha, c.prior_beta)]
        self.t = 0
        self.history: List[BOCPDStep] = []

    @property
    def change_probability(self) -> float:
        return self.run_probs[0] if self.run_probs else 1.0

    @property
    def most_probable_run_length(self) -> int:
        if not self.run_probs:
            return 0
        return max(range(len(self.run_probs)), key=self.run_probs.__getitem__)

    def _student_t_logpdf(self, x: float, n: int, mean: float, kappa: float, alpha: float, beta: float) -> float:
        # Posterior predictive Student-t under Normal-Inverse-Gamma prior.
        dof = max(1e-9, 2.0 * alpha)
        scale2 = beta * (kappa + 1.0) / (alpha * kappa)
        scale2 = max(scale2, 1e-12)
        # log t density
        lg = math.lgamma
        return (
            lg((dof + 1.0) / 2.0)
            - lg(dof / 2.0)
            - 0.5 * math.log(dof * math.pi * scale2)
            - ((dof + 1.0) / 2.0) * math.log1p(((x - mean) ** 2) / (dof * scale2))
        )

    def _update_stats(self, x: float, stat) -> tuple:
        n, mean, kappa, alpha, beta = stat
        kappa_new = kappa + 1.0
        mean_new = (kappa * mean + x) / kappa_new
        alpha_new = alpha + 0.5
        beta_new = beta + 0.5 * kappa * ((x - mean) ** 2) / kappa_new
        return n + 1, mean_new, kappa_new, alpha_new, beta_new

    def update(self, x: float) -> BOCPDStep:
        self.t += 1
        c = self.config
        H = 1.0 / max(1e-9, c.hazard_lambda)
        H = min(max(H, 0.0), 1.0)

        # Predictive likelihood for continuing each existing run.
        log_pred = [
            self._student_t_logpdf(x, *stat)
            for stat in self.stats
        ]

        # A change starts a NEW run, so its observation is scored under the
        # prior predictive distribution, not under each existing run's posterior.
        prior_stat = (0, c.prior_mean, c.prior_kappa, c.prior_alpha, c.prior_beta)
        log_pred_new_run = self._student_t_logpdf(x, *prior_stat)

        # Stable exponentiation using one shared offset.
        m = max([log_pred_new_run] + log_pred) if log_pred else log_pred_new_run
        pred = [math.exp(v - m) for v in log_pred]
        pred_new_run = math.exp(log_pred_new_run - m)

        n_old = len(self.run_probs)
        new_n = min(c.max_run_length + 1, n_old + 1)
        new_probs = [0.0] * new_n

        # Growth probabilities r_t = r_{t-1}+1
        for r in range(min(n_old, new_n - 1)):
            new_probs[r + 1] += self.run_probs[r] * pred[r] * (1.0 - H)

        # Change probability r_t = 0: hazard times the prior predictive.
        cp_mass = sum(self.run_probs[r] for r in range(n_old)) * H * pred_new_run
        new_probs[0] = cp_mass

        z = sum(new_probs)
        if not math.isfinite(z) or z <= 0.0:
            # Defensive fallback to avoid corrupting the filter under extreme numerics.
            new_probs = [1.0] + [0.0] * (new_n - 1)
            z = 1.0
        self.run_probs = [p / z for p in new_probs]

        # Update sufficient statistics. r=0 starts a new regime; r>0 extends old run.
        prior_stat = (0, c.prior_mean, c.prior_kappa, c.prior_alpha, c.prior_beta)
        next_stats = [self._update_stats(x, prior_stat)]
        for stat in self.stats[: new_n - 1]:
            next_stats.append(self._update_stats(x, stat))
        self.stats = next_stats[:new_n]

        step = BOCPDStep(
            t=self.t,
            observation=float(x),
            cp_probability=float(self.change_probability),
            most_probable_run_length=self.most_probable_run_length,
        )
        self.history.append(step)
        return step

    def update_many(self, xs: List[float]) -> List[BOCPDStep]:
        return [self.update(float(x)) for x in xs]
