from __future__ import annotations
import copy, json, math, statistics
from dataclasses import asdict
from pathlib import Path
from typing import Dict, List, Tuple, Any

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

from simulator import ScenarioFactory, WorldConfig, ResearchWorld, build_greedy_trace
from dynamics import OnlineDynamicsModel
from prediction_targets import OnlineTracePredictor, predict_reachability
from oracle import decision, rollout_decision

OUT = Path('/mnt/data/trace_research_simulator_v0.9/results/signal_selection_v1.json')

SIGNALS = [
    'reward_residual',
    'dynamics_residual',
    'trace_deviation',
    'objective_reachability',
]


def sigmoid(z):
    z = np.clip(z, -40, 40)
    return 1.0/(1.0+np.exp(-z))


def ece(y, p, bins=10):
    y=np.asarray(y); p=np.asarray(p)
    edges=np.linspace(0,1,bins+1)
    out=0.0
    for i in range(bins):
        m=(p>=edges[i]) & (p < edges[i+1] if i<bins-1 else p<=edges[i+1])
        if not m.any(): continue
        out += m.mean()*abs(y[m].mean()-p[m].mean())
    return float(out)


def safe_metric(fn, y, p, default=None):
    try:
        if len(set(y)) < 2:
            return default
        return float(fn(y,p))
    except Exception:
        return default


def fit_models(train_rows, feature_names):
    X={name: np.array([[r[name]] for r in train_rows], dtype=float) for name in feature_names}
    y=np.array([r['label'] for r in train_rows], dtype=int)
    models={}
    for name in feature_names:
        model=make_pipeline(StandardScaler(), LogisticRegression(max_iter=500, class_weight='balanced'))
        model.fit(X[name], y)
        models[name]=model
    Xc=np.array([[r[name] for name in feature_names] for r in train_rows], dtype=float)
    combined=make_pipeline(StandardScaler(), LogisticRegression(max_iter=500, class_weight='balanced'))
    combined.fit(Xc,y)
    models['combined']=combined
    # threshold maximizing F1 on TRAIN for each model
    thresholds={}
    for name, model in models.items():
        if name=='combined':
            probs=model.predict_proba(Xc)[:,1]
        else:
            probs=model.predict_proba(X[name])[:,1]
        best=(0.5, -1.0)
        for th in np.linspace(0.05,0.95,181):
            pred=(probs>=th).astype(int)
            tp=((pred==1)&(y==1)).sum(); fp=((pred==1)&(y==0)).sum(); fn=((pred==0)&(y==1)).sum()
            f1=0.0 if tp==0 else 2*tp/(2*tp+fp+fn)
            if f1>best[1]: best=(th,f1)
        thresholds[name]=best[0]
    return models, thresholds


def generate_profile_rows(profile, seeds, config):
    factory=ScenarioFactory(config)
    rows=[]
    for seed in seeds:
        scenario=factory.make(seed, profile)
        trace=build_greedy_trace(scenario)
        clean=copy.deepcopy(scenario)
        event_kinds={
            'local':'local_block',
            'regime':'regime_change',
            'structural':'structural_block',
            'adversarial':'opponent_intercept'
        }
        concrete=event_kinds[profile]
        clean.perturbations=[p for p in clean.perturbations if p.kind!=concrete]
        cw=ResearchWorld(clean); pw=ResearchWorld(scenario)
        cw.reset(); pw.reset()
        dyn=OnlineDynamicsModel(alpha=0.2, history_limit=100)
        predictor=OnlineTracePredictor(config.move_cost, config.wait_cost)
        event_start=min(p.start for p in scenario.perturbations if p.kind==concrete)
        prev_action=None; prev_feedback=None
        eval_steps=set([max(0,event_start-1), event_start, event_start+1, event_start+3, event_start+5, event_start+8])
        for step in range(max(0,event_start-1), min(config.horizon, event_start+9)):
            if step not in eval_steps:
                # Advance matched worlds without invoking expensive oracle; signals need history.
                co=cw.observe(); po=pw.observe(); action=trace[min(step,len(trace)-1)]
                cr=cw.step(action); pr=pw.step(action)
                prev_action=action; prev_feedback=pr.feedback
                realized_progress=1.0 if pr.truth.agent.pos!=po.agent_pos or (action.kind.name=='COLLECT' and pr.feedback.get('status') in {'executed','partial'}) else 0.0
                predictor.update(float(pr.feedback.get('reward',0.0)), realized_progress, pr.feedback.get('status') not in {'executed','partial'})
                continue
            co=cw.observe(); po=pw.observe()
            action=trace[min(step,len(trace)-1)]
            # Current dynamic residuals summarize the preceding transition.
            ds=dyn.update(po, prev_feedback, prev_action, action.target if action.kind.name in ('MOVE','COLLECT','RESERVE') else None)
            dyn_channels=dyn.detector_channels()
            reward_res=float(abs(dyn_channels.get('reward_residual',0.0)))
            dynamics_res=float(np.mean([abs(dyn_channels.get(k,0.0)) for k in (
                'kinematic_residual','status_surprise','resource_disappearance','opponent_approach','opponent_target_pressure')
            ]))
            ref_pos=cw.ground_truth().agent.pos
            trace_dev=float(abs(po.agent_pos[0]-ref_pos[0])+abs(po.agent_pos[1]-ref_pos[1]))
            rr=predict_reachability(po, action.target, horizon=5, predictor=predictor)
            reach_signal=1.0-float(rr.predicted_probability)

            # Oracle transition: compare perturbed vs clean trace optimality.
            d_clean=rollout_decision(cw, action, depth=3, beam_width=3)
            d_pert=rollout_decision(pw, action, depth=3, beam_width=3)
            delta_gap=float(d_pert.optimality_gap-d_clean.optimality_gap)
            # Strict causal event: the perturbation materially worsens the trace
            # relative to the matched clean world, or makes it obsolete.
            label=int((delta_gap >= 0.25) or (d_pert.trace_obsolete and not d_clean.trace_obsolete))
            rows.append({
                'profile': profile,'seed':seed,'step':step,'event_start':event_start,
                'reward_residual':reward_res,
                'dynamics_residual':dynamics_res,
                'trace_deviation':trace_dev,
                'objective_reachability':reach_signal,
                'label':label,
                'delta_gap':delta_gap,
                'clean_gap':float(d_clean.optimality_gap),
                'pert_gap':float(d_pert.optimality_gap),
                'clean_obsolete':bool(d_clean.trace_obsolete),
                'pert_obsolete':bool(d_pert.trace_obsolete),
            })
            # Execute same trace action in both matched worlds.
            cr=cw.step(action); pr=pw.step(action)
            prev_action=action
            prev_feedback=pr.feedback
            # predictor update from perturbed feedback
            realized_progress=1.0 if pr.truth.agent.pos!=po.agent_pos or (action.kind.name=='COLLECT' and pr.feedback.get('status') in {'executed','partial'}) else 0.0
            predictor.update(float(pr.feedback.get('reward',0.0)), realized_progress, pr.feedback.get('status') not in {'executed','partial'})
            if cr.done or pr.done: break
    return rows


def evaluate(model, test_rows, feature_names, threshold, name):
    y=np.array([r['label'] for r in test_rows], dtype=int)
    if name=='combined': X=np.array([[r[f] for f in feature_names] for r in test_rows], dtype=float)
    else: X=np.array([[r[name]] for r in test_rows], dtype=float)
    p=model.predict_proba(X)[:,1]
    pred=(p>=threshold).astype(int)
    f1=[]
    tp=((pred==1)&(y==1)).sum(); fp=((pred==1)&(y==0)).sum(); fn=((pred==0)&(y==1)).sum()
    f1v=0.0 if tp==0 else 2*tp/(2*tp+fp+fn)
    return {
        'n':int(len(y)), 'positive_rate':float(y.mean()),
        'auroc':safe_metric(roc_auc_score,y,p),
        'auprc':safe_metric(average_precision_score,y,p),
        'brier':float(brier_score_loss(y,p)),
        'ece':ece(y,p), 'f1':float(f1v), 'threshold':float(threshold),
    }


def episode_detection_stats(model, test_rows, feature_names, threshold, name):
    # Find first oracle transition per episode and first predicted detection at/after event start.
    groups={}
    for r in test_rows: groups.setdefault((r['profile'],r['seed']),[]).append(r)
    delays=[]; misses=0; false_before=0; eligible=0
    for key, rows in groups.items():
        rows=sorted(rows,key=lambda r:r['step'])
        y=[r['label'] for r in rows]
        transitions=[r['step'] for i,r in enumerate(rows) if r['label']==1 and (i==0 or rows[i-1]['label']==0)]
        if not transitions: continue
        oracle_t=transitions[0]; eligible += 1
        if name=='combined': X=np.array([[r[f] for f in feature_names] for r in rows],dtype=float)
        else: X=np.array([[r[name]] for r in rows],dtype=float)
        p=model.predict_proba(X)[:,1]
        detected=None
        for r,pp in zip(rows,p):
            if r['step']>=r['event_start'] and pp>=threshold:
                detected=r['step']; break
        if detected is None:
            misses += 1
        else:
            delays.append(max(0,detected-oracle_t))
        # false alarm before event start
        if any(pp>=threshold for r,pp in zip(rows,p) if r['step']<r['event_start']):
            false_before += 1
    return {
        'eligible_episodes':eligible,
        'mean_detection_delay':float(statistics.mean(delays)) if delays else None,
        'median_detection_delay':float(statistics.median(delays)) if delays else None,
        'miss_rate':float(misses/max(1,eligible)),
        'pre_event_false_alarm_rate':float(false_before/max(1,len(groups))),
    }


def main():
    config=WorldConfig(horizon=55)
    profiles=['local','regime','structural','adversarial']
    train_seeds=range(0,20)
    test_seeds=range(20,30)
    train=[]; test=[]
    for p in profiles:
        tr=generate_profile_rows(p,train_seeds,config)
        te=generate_profile_rows(p,test_seeds,config)
        train.extend(tr); test.extend(te)
        print(p, 'train',len(tr),'test',len(te), flush=True)

    models, thresholds=fit_models(train, SIGNALS)
    results={'train_rows':len(train),'test_rows':len(test),'signals':SIGNALS,'models':{}}
    for name in SIGNALS+['combined']:
        res=evaluate(models[name], test, SIGNALS, thresholds[name], name)
        det=episode_detection_stats(models[name], test, SIGNALS, thresholds[name], name)
        results['models'][name]={**res, **det}

    # Profile-level discrimination for interpretability.
    results['by_profile']={}
    for p in profiles:
        pt=[r for r in test if r['profile']==p]
        results['by_profile'][p]={}
        for name in SIGNALS+['combined']:
            results['by_profile'][p][name]=evaluate(models[name],pt,SIGNALS,thresholds[name],name)

    # Simple ranking: prefer AUPRC, then Brier/ECE, while penalizing misses.
    ranking=[]
    for name,res in results['models'].items():
        auprc=res['auprc'] or 0.0
        brier=res['brier']
        miss=res['miss_rate']
        score=auprc - 0.35*brier - 0.35*miss
        ranking.append((name,score))
    results['ranking']=sorted(ranking,key=lambda x:x[1],reverse=True)
    OUT.write_text(json.dumps(results,indent=2),encoding='utf-8')
    print(json.dumps(results['models'],indent=2))
    print('RANKING',results['ranking'])

if __name__=='__main__': main()
