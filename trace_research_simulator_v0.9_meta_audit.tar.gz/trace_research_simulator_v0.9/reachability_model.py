from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Tuple, List, Dict
import math

from simulator import Observation, Pos

@dataclass
class ReachabilityModel:
    """Small hand-calibrated logistic model; coefficients are fitted offline, not oracle-exposed online."""
    bias: float = -0.5
    w_dist: float = -0.35
    w_slack: float = 0.55
    w_visible: float = 1.1
    w_blocked: float = -0.7
    w_opponent: float = -0.25
    w_failure: float = -0.5

    @staticmethod
    def _sigmoid(x: float) -> float:
        x=max(-30.0,min(30.0,x))
        return 1.0/(1.0+math.exp(-x))

    def features(self, obs: Observation, target: Optional[Pos], horizon: int, failure_rate: float=0.05) -> List[float]:
        if target is None:
            return [0,0,0,0,0,0]
        dist=abs(target[0]-obs.agent_pos[0])+abs(target[1]-obs.agent_pos[1])
        visible=float(any(r.pos==target and r.available for r in obs.visible_resources.values()))
        blocked=float(sum(1 for p in obs.blocked_visible if abs(p[0]-obs.agent_pos[0])+abs(p[1]-obs.agent_pos[1])<=dist+1))
        opp=0.0
        if obs.visible_opponents:
            opp=min(abs(o.pos[0]-target[0])+abs(o.pos[1]-target[1]) for o in obs.visible_opponents.values())
        opp_pressure=math.exp(-opp/4.0)
        slack=horizon-dist
        return [dist, slack, visible, blocked, opp_pressure, failure_rate]

    def predict_from_features(self, feats: List[float]) -> float:
        dist,slack,visible,blocked,opp,failure=feats
        z=(self.bias+self.w_dist*dist+self.w_slack*slack+self.w_visible*visible+self.w_blocked*blocked+self.w_opponent*opp+self.w_failure*failure)
        return self._sigmoid(z)
