from __future__ import annotations
import copy, json, statistics
from pathlib import Path
import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss

from simulator import ScenarioFactory, WorldConfig, ResearchWorld, build_greedy_trace
from dynamics import OnlineDynamicsModel
from prediction_targets import OnlineTracePredictor, predict_reachability
from oracle import rollout_decision

OUT=Path('/mnt/data/trace_research_simulator_v0.9/results/signal_selection_eventpoint_v1.json')
SIGNALS=['reward_residual','dynamics_residual','trace_deviation','objective_reachability']
KIND={'local':'local_block','regime':'regime_change','structural':'structural_block','adversarial':'opponent_intercept'}


def ece(y,p,bins=10):
    y=np.asarray(y); p=np.asarray(p); out=0.0
    for lo,hi in zip(np.linspace(0,1,bins+1)[:-1],np.linspace(0,1,bins+1)[1:]):
        m=(p>=lo)&(p<hi if hi<1 else p<=hi)
        if m.any(): out += m.mean()*abs(y[m].mean()-p[m].mean())
    return float(out)


def episode_rows(profile,seeds,cfg,roll_depth=3):
    rows=[]; fac=ScenarioFactory(cfg)
    for seed in seeds:
        sc=fac.make(seed,profile); trace=build_greedy_trace(sc); kind=KIND[profile]
        event_start=min(p.start for p in sc.perturbations if p.kind==kind)
        clean=copy.deepcopy(sc); clean.perturbations=[p for p in clean.perturbations if p.kind!=kind]
        cw=ResearchWorld(clean); pw=ResearchWorld(sc); cw.reset(); pw.reset()
        dyn=OnlineDynamicsModel(alpha=0.2); pred=OnlineTracePredictor(cfg.move_cost,cfg.wait_cost)
        prev_a=None; prev_fb=None
        for step in range(event_start+1):
            co,po=cw.observe(),pw.observe(); a=trace[min(step,len(trace)-1)]
            if step==event_start:
                dyn.update(po,prev_fb,prev_a,a.target)
                ch=dyn.detector_channels()
                reward=float(abs(ch.get('reward_residual',0.0)))
                dynv=float(np.mean([abs(ch.get(k,0.0)) for k in ('kinematic_residual','status_surprise','resource_disappearance','opponent_approach','opponent_target_pressure')]))
                ref=cw.ground_truth().agent.pos
                dev=float(abs(po.agent_pos[0]-ref[0])+abs(po.agent_pos[1]-ref[1]))
                reach=1.0-predict_reachability(po,a.target,5,pred).predicted_probability
                dc=rollout_decision(cw,a,depth=roll_depth,beam_width=2)
                dp=rollout_decision(pw,a,depth=roll_depth,beam_width=2)
                delta=float(dp.optimality_gap-dc.optimality_gap)
                rows.append({'profile':profile,'seed':seed,'reward_residual':reward,'dynamics_residual':dynv,'trace_deviation':dev,'objective_reachability':reach,'delta_gap':delta,'clean_obsolete':int(dc.trace_obsolete),'pert_obsolete':int(dp.trace_obsolete)})
                break
            cr=cw.step(a); pr=pw.step(a); prev_a=a; prev_fb=pr.feedback
            prog=1.0 if pr.truth.agent.pos!=po.agent_pos or (a.kind.name=='COLLECT' and pr.feedback.get('status') in {'executed','partial'}) else 0.0
            pred.update(float(pr.feedback.get('reward',0.0)),prog,pr.feedback.get('status') not in {'executed','partial'})
    return rows


def metrics(train,test,signal):
    Xtr=np.array([[r[signal]] for r in train]); Xt=np.array([[r[signal]] for r in test])
    ytr=np.array([int(r['label']) for r in train]); yt=np.array([int(r['label']) for r in test])
    clf=make_pipeline(StandardScaler(),LogisticRegression(max_iter=500,class_weight='balanced')).fit(Xtr,ytr)
    p=clf.predict_proba(Xt)[:,1]
    return {'auroc':None if len(set(yt))<2 else float(roc_auc_score(yt,p)), 'auprc':None if len(set(yt))<2 else float(average_precision_score(yt,p)), 'brier':float(brier_score_loss(yt,p)), 'ece':ece(yt,p)}


def regression_metrics(train,test,signal):
    Xtr=np.array([[r[signal]] for r in train]); Xt=np.array([[r[signal]] for r in test])
    ytr=np.array([r['delta_gap'] for r in train]); yt=np.array([r['delta_gap'] for r in test])
    m=make_pipeline(StandardScaler(),Ridge(alpha=1.0)).fit(Xtr,ytr)
    p=m.predict(Xt)
    corr=float(np.corrcoef(p,yt)[0,1]) if np.std(p)>1e-12 and np.std(yt)>1e-12 else None
    mse=float(np.mean((p-yt)**2))
    return {'corr':corr,'mse':mse,'mean_pred':float(np.mean(p)),'mean_true':float(np.mean(yt))}


def main():
    cfg=WorldConfig(horizon=55)
    train=[]; test=[]
    for p in KIND:
        tr=episode_rows(p,range(0,30),cfg); te=episode_rows(p,range(30,50),cfg)
        # A causal harm label: rollout gap >= 0.05 OR obsolete flip.
        for r in tr: r['label']=int(r['delta_gap']>=0.05 or (r['pert_obsolete'] and not r['clean_obsolete']))
        for r in te: r['label']=int(r['delta_gap']>=0.05 or (r['pert_obsolete'] and not r['clean_obsolete']))
        train+=tr; test+=te
        print(p,'train',len(tr),'pos',sum(r['label'] for r in tr),'test',len(te),'pos',sum(r['label'] for r in te),flush=True)
    out={'n_train':len(train),'n_test':len(test),'train_positive_rate':float(np.mean([r['label'] for r in train])),'test_positive_rate':float(np.mean([r['label'] for r in test])),'models':{},'by_profile':{}}
    for s in SIGNALS:
        out['models'][s]={**metrics(train,test,s),**regression_metrics(train,test,s)}
    Xtr=np.array([[r[s] for s in SIGNALS] for r in train]); Xt=np.array([[r[s] for s in SIGNALS] for r in test]); ytr=np.array([r['label'] for r in train]); yt=np.array([r['label'] for r in test]); rgtr=np.array([r['delta_gap'] for r in train]); rgt=np.array([r['delta_gap'] for r in test])
    clf=make_pipeline(StandardScaler(),LogisticRegression(max_iter=500,class_weight='balanced')).fit(Xtr,ytr); p=clf.predict_proba(Xt)[:,1]
    ridge=make_pipeline(StandardScaler(),Ridge(alpha=1.0)).fit(Xtr,rgtr); rp=ridge.predict(Xt)
    out['models']['combined']={'auroc':None if len(set(yt))<2 else float(roc_auc_score(yt,p)),'auprc':None if len(set(yt))<2 else float(average_precision_score(yt,p)),'brier':float(brier_score_loss(yt,p)),'ece':ece(yt,p),'corr':float(np.corrcoef(rp,rgt)[0,1]) if np.std(rp)>1e-12 and np.std(rgt)>1e-12 else None,'mse':float(np.mean((rp-rgt)**2))}
    for p in KIND:
        pt=[r for r in test if r['profile']==p]
        out['by_profile'][p]={}
        for s in SIGNALS:
            out['by_profile'][p][s]=regression_metrics([r for r in train if r['profile']==p],pt,s)
    OUT.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps(out,indent=2))

if __name__=='__main__': main()
