from __future__ import annotations
from typing import Any, List, Optional

from simulator import Action, ActionType, Observation


class AgentBase:
    name = "agent"

    def reset(self) -> None:
        pass

    def act(self, obs: Observation, feedback: Optional[dict]) -> Action:
        raise NotImplementedError


class TraceOnlyAgent(AgentBase):
    name = "trace_only"

    def __init__(self, trace: List[Action]):
        self.trace = trace

    def act(self, obs: Observation, feedback: Optional[dict]) -> Action:
        return self.trace[min(obs.step, len(self.trace) - 1)]


class ReactiveRepairAgent(TraceOnlyAgent):
    name = "trace_reactive"

    def act(self, obs: Observation, feedback: Optional[dict]) -> Action:
        base = super().act(obs, feedback)
        if feedback and feedback.get("status") == "partial" and feedback.get("remainder"):
            rem = feedback["remainder"]
            return Action(ActionType(rem["kind"]), tuple(rem["target"]) if rem.get("target") else None)
        if obs.blocked_visible and base.kind == ActionType.MOVE and base.target in obs.blocked_visible:
            tx, ty = base.target
            x, y = obs.agent_pos
            candidates = []
            for q in ((x+1,y),(x-1,y),(x,y+1),(x,y-1)):
                if q not in obs.blocked_visible and q != obs.agent_pos:
                    candidates.append(q)
            if candidates:
                detour = min(candidates, key=lambda q: abs(q[0]-tx)+abs(q[1]-ty))
                return Action(ActionType.MOVE, base.target) if detour == obs.agent_pos else Action(ActionType.MOVE, detour)
            return Action(ActionType.WAIT)
        return base


class ChangeAwareAgent(ReactiveRepairAgent):
    name = "trace_change_aware"

    def __init__(self, trace: List[Action], threshold: float = 0.6):
        super().__init__(trace)
        self.threshold = threshold

    def act(self, obs: Observation, feedback: Optional[dict]) -> Action:
        if obs.regime_signal >= self.threshold:
            # Conservative de-risking action: pause rather than commit to a
            # trace whose transition costs have changed.
            return Action(ActionType.WAIT)
        return super().act(obs, feedback)


class OpportunisticAgent(TraceOnlyAgent):
    name = "trace_opportunistic"

    def act(self, obs: Observation, feedback: Optional[dict]) -> Action:
        if obs.future_resource_pressure and obs.visible_resources:
            resource = min(
                obs.visible_resources.values(),
                key=lambda r: abs(r.pos[0] - obs.agent_pos[0]) + abs(r.pos[1] - obs.agent_pos[1]),
            )
            return Action(ActionType.RESERVE, resource.pos)
        return super().act(obs, feedback)


class TriggeredReplanAgent(ReactiveRepairAgent):
    name = "trace_triggered_replan"

    def act(self, obs: Observation, feedback: Optional[dict]) -> Action:
        base = super().act(obs, feedback)
        triggered = bool(obs.regime_signal >= 0.6 or obs.blocked_visible or (feedback and feedback.get("status") in {"no_resource", "reserve_failed"}))
        if not triggered:
            return base
        if not obs.visible_resources:
            return Action(ActionType.WAIT)
        target_resource = min(
            obs.visible_resources.values(),
            key=lambda r: abs(r.pos[0]-obs.agent_pos[0]) + abs(r.pos[1]-obs.agent_pos[1]),
        )
        if target_resource.pos == obs.agent_pos:
            return Action(ActionType.COLLECT, target_resource.pos)
        return Action(ActionType.MOVE, target_resource.pos)


class ReplanAgent(TraceOnlyAgent):
    name = "trace_replan"

    def act(self, obs: Observation, feedback: Optional[dict]) -> Action:
        if feedback and feedback.get("status") == "partial" and feedback.get("remainder"):
            rem = feedback["remainder"]
            return Action(ActionType(rem["kind"]), tuple(rem["target"]) if rem.get("target") else None)

        # Reactive replanning uses currently visible resources and does not
        # assume the original trace remains valid.
        if obs.regime_signal >= 0.6 or not obs.visible_resources:
            return Action(ActionType.WAIT)
        target_resource = min(
            obs.visible_resources.values(),
            key=lambda r: abs(r.pos[0] - obs.agent_pos[0]) + abs(r.pos[1] - obs.agent_pos[1]),
        )
        if target_resource.pos == obs.agent_pos:
            return Action(ActionType.COLLECT, target_resource.pos)
        return Action(ActionType.MOVE, target_resource.pos)
