from __future__ import annotations
import json, math, statistics, sys
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from simulator import ScenarioFactory, WorldConfig, Perturbation
from agents import TraceOnlyAgent, ReactiveRepairAgent, ChangeAwareAgent, OpportunisticAgent, ReplanAgent, TriggeredReplanAgent
from evaluation import run_episode

FACTORIES={"trace_only":TraceOnlyAgent,"trace_reactive":ReactiveRepairAgent,"trace_change_aware":ChangeAwareAgent,"trace_opportunistic":OpportunisticAgent,"trace_triggered_replan":TriggeredReplanAgent, "trace_replan":ReplanAgent}

def mean_ci(v):
    m=statistics.mean(v)
    if len(v)<2:return m,0.0
    return m,1.96*statistics.stdev(v)/math.sqrt(len(v))

def task(arg):
    profile,axis,value,seed,agent_name=arg
    cfg=WorldConfig(width=9,height=9,horizon=60,n_resources=7,n_opponents=1,stochasticity=0.01)
    if axis=="opponent_strength": cfg.opponent_strength=value
    if axis=="regime_multiplier": cfg.regime_move_cost_multiplier=value
    s=ScenarioFactory(cfg).make(seed,profile)
    patched=[]
    for p in s.perturbations:
        mag=value if axis=="magnitude" else 1.0
        obsq=value if axis=="observability" else 1.0
        patched.append(Perturbation(p.kind,p.start,p.duration,p.target,mag,obsq,p.seed))
    s.perturbations=patched
    m=run_episode(s,FACTORIES[agent_name])
    return (profile,axis,value,agent_name,m.total_reward,float(m.success),m.catastrophic_failures,m.recovery_debt)

def main():
    seeds=list(range(12))
    profiles=["local","regime","structural","adversarial"]
    axes=[("magnitude",[0.25,0.75,1.25,1.75]),("observability",[0.2,0.5,0.8,1.0]),("opponent_strength",[0.1,0.4,0.7,0.9]),("regime_multiplier",[1.0,1.75,2.5,3.5])]
    tasks=[(p,a,v,s,n) for p in profiles for a,vs in axes for v in vs for s in seeds for n in FACTORIES]
    rows=[]
    with ProcessPoolExecutor(max_workers=8) as ex:
        for i,r in enumerate(ex.map(task,tasks,chunksize=8),1):
            rows.append(r)
            if i%1000==0: print("done",i,len(tasks),flush=True)
    agg={}
    for p,a,v,n,r,sc,cat,debt in rows:
        k=(p,a,v,n); agg.setdefault(k,[]).append((r,sc,cat,debt))
    out=[]
    for (p,a,v,n),vals in agg.items():
        rewards=[x[0] for x in vals]
        m,ci=mean_ci(rewards)
        out.append({"profile":p,"axis":a,"value":v,"agent":n,"n":len(vals),"mean_reward":m,"ci95_reward":ci,"success_rate":statistics.mean(x[1] for x in vals),"mean_catastrophic_failures":statistics.mean(x[2] for x in vals),"mean_recovery_debt":statistics.mean(x[3] for x in vals)})
    outdir=ROOT/"results";outdir.mkdir(exist_ok=True)
    json.dump(out,open(outdir/"stress_sweep_fast.json","w"),indent=2)
    print("wrote",len(out))
if __name__=='__main__':main()
