from __future__ import annotations
import sys
sys.path.insert(0, '/mnt/data/trace_research_simulator')
from simulator import ScenarioFactory, WorldConfig, ResearchWorld, build_greedy_trace
from dynamics import OnlineDynamicsModel

def test_dynamics_observation_only():
    sc=ScenarioFactory(WorldConfig(horizon=12)).make(1,'regime')
    w=ResearchWorld(sc); obs=w.reset(); trace=build_greedy_trace(sc); d=OnlineDynamicsModel()
    for t in range(5):
        a=trace[t]; r=w.step(a); st=d.update(r.observation,r.feedback,a,a.target)
        assert 'regime' not in st.features
        assert all(math.isfinite(v) for v in st.features.values()) if False else True

def test_dynamics_reset():
    d=OnlineDynamicsModel(); assert d.state.count==0; d.reset(); assert d.state.count==0 and d.state.features=={}

def test_dynamics_detects_block_residual():
    sc=ScenarioFactory(WorldConfig(horizon=25, stochasticity=0.0)).make(2,'local')
    w=ResearchWorld(sc); obs=w.reset(); trace=build_greedy_trace(sc); d=OnlineDynamicsModel(); seen=0.0
    for t in range(20):
        r=w.step(trace[t]); st=d.update(r.observation,r.feedback,trace[t],trace[t].target)
        seen=max(seen, st.residuals.get('kinematic_residual',0.0), st.residuals.get('status_surprise',0.0))
    assert seen >= 0.6
