from simulator import ScenarioFactory, WorldConfig
from validity import compute_validity_curve, causal_validity_curve, summarize_curves


def test_validity_curve_shapes():
    sc = ScenarioFactory(WorldConfig(horizon=25)).make(1, "regime")
    ep = compute_validity_curve(sc, horizons=(1, 3), beam_width=2)
    assert ep.points
    assert {p.horizon for p in ep.points} == {1, 3}
    assert all(p.optimality_gap >= 0 for p in ep.points)


def test_causal_curve_has_pre_and_post_event_points():
    sc = ScenarioFactory(WorldConfig(horizon=50)).make(2, "regime")
    pts = causal_validity_curve(sc, "regime_change", horizons=(1, 3), window=2, beam_width=2)
    assert pts
    assert min(p.step for p in pts) <= 26
    assert max(p.step for p in pts) >= 28


def test_summary():
    sc = ScenarioFactory(WorldConfig(horizon=20)).make(3, "local")
    ep = compute_validity_curve(sc, horizons=(1,), beam_width=2)
    s = summarize_curves([ep])
    assert s["episodes"] == 1
    assert "1" in s["by_horizon"]
