from simulator import ScenarioFactory, WorldConfig
from prediction_targets import OnlineTracePredictor, predict_reachability, matched_target_evaluation


def test_predictor_is_observation_only():
    cfg=WorldConfig(horizon=20)
    sc=ScenarioFactory(cfg).make(11,"local")
    w=__import__('simulator').ResearchWorld(sc)
    obs=w.observe()
    p=OnlineTracePredictor()
    pred=p.predict(obs, __import__('simulator').build_greedy_trace(sc)[0], None)
    assert 0.0 <= pred.uncertainty <= 1.0


def test_reachability_bounds():
    cfg=WorldConfig(horizon=20)
    sc=ScenarioFactory(cfg).make(12,"regime")
    w=__import__('simulator').ResearchWorld(sc)
    obs=w.observe(); p=OnlineTracePredictor()
    target=next(iter(obs.visible_resources.values())).pos
    r=predict_reachability(obs,target,5,p)
    assert 0.0 <= r.predicted_probability <= 1.0


def test_matched_records_nonempty():
    cfg=WorldConfig(horizon=30)
    sc=ScenarioFactory(cfg).make(13,"structural")
    rec=matched_target_evaluation(sc,"structural",horizons=(3,5))
    assert rec
    assert all(0.0 <= r.oracle_reachability <= 1.0 for r in rec)


def test_no_truth_leak_in_predictor():
    p=OnlineTracePredictor()
    assert not hasattr(p,"truth")
    assert not hasattr(p,"world")
