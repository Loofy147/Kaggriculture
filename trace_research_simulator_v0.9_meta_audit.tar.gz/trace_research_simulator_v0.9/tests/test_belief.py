from __future__ import annotations
import sys
sys.path.insert(0, '/mnt/data/trace_research_simulator')
from simulator import ScenarioFactory, WorldConfig, ResearchWorld, Action, ActionType
from belief import MultiChannelBelief

def test_belief_does_not_use_regime_signal():
    sc=ScenarioFactory(WorldConfig(horizon=10)).make(1,'regime')
    w=ResearchWorld(sc); obs=w.reset(); b=MultiChannelBelief(); st=b.update(obs, {'reward':0.0,'executed':True,'status':'executed'})
    assert 'regime_signal' not in st.features

def test_belief_channels_are_observation_only_and_finite():
    sc=ScenarioFactory(WorldConfig(horizon=15)).make(2,'mixed')
    w=ResearchWorld(sc); obs=w.reset(); b=MultiChannelBelief()
    for _ in range(10):
        r=w.step(Action(ActionType.WAIT)); st=b.update(r.observation,r.feedback)
        assert all(v==v and abs(v)<1e12 for v in st.features.values())
        assert all(v==v and abs(v)<1e12 for v in st.deltas.values())
        if r.done: break

def test_belief_state_resets():
    b=MultiChannelBelief(); sc=ScenarioFactory(WorldConfig()).make(3,'local'); w=ResearchWorld(sc); o=w.reset(); b.update(o, None); assert b.state.count==1; b.reset(); assert b.state.count==0 and b.state.features=={}
