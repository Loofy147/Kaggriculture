from simulator import ScenarioFactory, WorldConfig, ResearchWorld, build_greedy_trace


def _run(sc):
    w = ResearchWorld(sc); w.reset(); tr = build_greedy_trace(sc)
    for _ in range(sc.config.horizon):
        w.step(tr[min(w.ground_truth().step, len(tr)-1)])
        if w.ground_truth().step >= sc.config.horizon:
            break
    t = w.ground_truth()
    return t.collected_goals, t.lost_goals, t.total_reward


def test_structural_profile_can_change_goal_reachability():
    cfg=WorldConfig(horizon=45)
    fac=ScenarioFactory(cfg)
    changed=0
    for seed in range(1,9):
        pert=fac.make(seed,'structural')
        target=[p.target for p in pert.perturbations if p.kind=='structural_block'][0]
        w=ResearchWorld(pert); w.reset()
        for _ in range(18): w.step(build_greedy_trace(pert)[w.ground_truth().step])
        w._update_truth_effects()
        if target in w.ground_truth().blocked: changed += 1
    assert changed >= 1


def test_adversarial_profile_can_change_capture_outcome():
    cfg=WorldConfig(horizon=45)
    fac=ScenarioFactory(cfg)
    changed=0
    for seed in range(1,13):
        pert=fac.make(seed,'adversarial')
        clean=fac.make(seed,'local'); clean.perturbations=[]
        a=_run(pert); b=_run(clean)
        if a[:2] != b[:2]: changed += 1
    assert changed >= 1
