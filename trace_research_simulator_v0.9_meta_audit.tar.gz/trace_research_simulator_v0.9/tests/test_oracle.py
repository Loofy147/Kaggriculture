from __future__ import annotations
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from simulator import ScenarioFactory, WorldConfig, Action, ActionType
from oracle import decision, run_oracle_episode


def test_oracle_returns_decision():
    s=ScenarioFactory(WorldConfig(horizon=20,n_resources=4)).make(3,'local')
    from simulator import ResearchWorld, build_greedy_trace
    w=ResearchWorld(s); w.reset()
    d=decision(w, build_greedy_trace(s)[0])
    assert d.oracle_action is not None
    assert d.optimality_gap >= -1e-9


def test_obsolete_is_stronger_than_invalid():
    s=ScenarioFactory(WorldConfig(horizon=20,n_resources=4)).make(5,'regime')
    e=run_oracle_episode(s, valid_epsilon=0.25, obsolete_epsilon=0.01)
    assert all(d.trace_obsolete for d in e.decisions if d.optimality_gap >= 0.01)


def test_oracle_does_not_change_world():
    s=ScenarioFactory(WorldConfig(horizon=20,n_resources=4)).make(7,'mixed')
    from simulator import ResearchWorld, build_greedy_trace
    w=ResearchWorld(s); w.reset()
    before=w.ground_truth()
    _=decision(w, build_greedy_trace(s)[0])
    after=w.ground_truth()
    assert before.step == after.step
    assert before.agent.pos == after.agent.pos
    assert before.total_reward == after.total_reward
