from __future__ import annotations
import sys
sys.path.insert(0, "/mnt/data/trace_research_simulator")

from bocpd import GaussianBOCPD, GaussianBOCPDConfig
from detector_features import scalar_observable


def test_bocpd_change_probability_stays_bounded():
    d = GaussianBOCPD(GaussianBOCPDConfig(hazard_lambda=30.0, max_run_length=50))
    xs = [0.0] * 20 + [4.0] * 20
    steps = d.update_many(xs)
    assert all(0.0 <= s.cp_probability <= 1.0 for s in steps)
    assert len(d.run_probs) <= 51


def test_bocpd_detects_obvious_mean_shift():
    d = GaussianBOCPD(GaussianBOCPDConfig(hazard_lambda=30.0, max_run_length=100))
    xs = [0.0] * 30 + [5.0] * 30
    steps = d.update_many(xs)
    peak_after = max(s.cp_probability for s in steps[30:])
    assert peak_after > 0.5


def test_observable_feature_does_not_leak_regime_signal():
    class O:
        regime_signal = 0.99
        step = 0
    # Uses only supplied feedback and action; regime_signal is ignored.
    value = scalar_observable(O(), {"reward": -1.0, "executed": False, "status": "blocked"}, None)
    assert value == -2.0
