from __future__ import annotations
import copy, json, statistics, time
from pathlib import Path
import numpy as np
from scipy.stats import spearmanr, pearsonr
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_squared_error
from simulator import ScenarioFactory, WorldConfig, ResearchWorld, build_greedy_trace
from dynamics import OnlineDynamicsModel
from prediction_targets import OnlineTracePredictor, predict_reachability
from oracle import rollout_decision
ROOT=Path('/mnt/data/trace_research_simulator_v0.9'); OUT=ROOT/'results/temporal_association_small_v1.json'; REPORT=ROOT/'RESEARCH_REPORT_temporal_association_small_v1.md'
KIND={'local':'local_block','regime':'regime_change','structural':'structural_block','adversarial':'opponent_intercept'}
SIGNALS=['reward_residual','dynamics_residual','trace_deviation','objective_reachability']

def run(profile, seed, cfg, pre=3, post=8):
    fac=ScenarioFactory(cfg); sc=fac.make(seed,profile); trace=build_greedy_trace(sc); ek=KIND[profile]; ev=min(p.start for p in sc.perturbations if p.kind==ek)
    clean=copy.deepcopy(sc); clean.perturbations=[p for p in clean.perturbations if p.kind!=ek]
    cw=ResearchWorld(clean); pw=ResearchWorld(sc); cw.reset(); pw.reset(); dyn=OnlineDynamicsModel(alpha=.2); pred=OnlineTracePredictor(cfg.move_cost,cfg.wait_cost)
    prev_a=None; prev_fb=None; rows=[]; lo=max(0,ev-pre); hi=min(cfg.horizon-1,ev+post)
    for step in range(hi+1):
        co,po=cw.observe(),pw.observe(); a=trace[min(step,len(trace)-1)]
        if step>=lo:
            dyn.update(po,prev_fb,prev_a,a.target); ch=dyn.detector_channels()
            reward=abs(float(ch.get('reward_residual',0.))); dynv=float(np.mean([abs(ch.get(k,0.)) for k in ('kinematic_residual','status_surprise','resource_disappearance','opponent_approach','opponent_target_pressure')]))
            ref=cw.ground_truth().agent.pos; dev=float(abs(po.agent_pos[0]-ref[0])+abs(po.agent_pos[1]-ref[1]))
            reach=1.-predict_reachability(po,a.target,5,pred).predicted_probability
            dc=rollout_decision(cw,a,depth=3,beam_width=2); dp=rollout_decision(pw,a,depth=3,beam_width=2)
            delta=float(dp.optimality_gap-dc.optimality_gap)
            rows.append({'profile':profile,'seed':seed,'rel_step':step-ev,'delta_gap':delta,'label_soft':float(max(0.,delta)),'reward_residual':reward,'dynamics_residual':dynv,'trace_deviation':dev,'objective_reachability':reach})
        cr=cw.step(a); pr=pw.step(a); prev_a=a; prev_fb=pr.feedback
        prog=1. if pr.truth.agent.pos!=po.agent_pos or (a.kind.name=='COLLECT' and pr.feedback.get('status') in {'executed','partial'}) else 0.
        pred.update(float(pr.feedback.get('reward',0.)),prog,pr.feedback.get('status') not in {'executed','partial'})
        if cr.done or pr.done: break
    return rows

def corr(x,y):
    if len(set(x))<2 or len(set(y))<2: return {'pearson':None,'spearman':None}
    return {'pearson':float(pearsonr(x,y).statistic),'spearman':float(spearmanr(x,y).statistic)}

def main():
    t=time.time(); cfg=WorldConfig(horizon=55); train=[]; test=[]
    for p in KIND:
        for s in range(0,4): train += run(p,s,cfg)
        for s in range(4,8): test += run(p,s,cfg)
        print(p,'train rows',len([r for r in train if r['profile']==p]),'test rows',len([r for r in test if r['profile']==p]),flush=True)
    out={'profiles':{},'pooled':{}}
    for p in KIND:
        rr=[r for r in test if r['profile']==p]; out['profiles'][p]={}
        for rel in sorted(set(r['rel_step'] for r in rr)):
            x=[r for r in rr if r['rel_step']==rel]; out['profiles'][p][str(rel)]={'n':len(x)}
            y=[r['delta_gap'] for r in x]
            for sig in SIGNALS: out['profiles'][p][str(rel)][sig]=corr([r[sig] for r in x],y)
    for sig in SIGNALS:
        vals=[r[sig] for r in test]; y=[r['delta_gap'] for r in test]; out['pooled'][sig]=corr(vals,y)
    # Fit pooled ridge and per-profile ridge on training, evaluate held-out continuous delta gap.
    for sigset_name, cols in [(s,[s]) for s in SIGNALS]+[('combined',SIGNALS)]:
        Xtr=np.array([[r[c] for c in cols] for r in train]); ytr=np.array([r['delta_gap'] for r in train]); Xt=np.array([[r[c] for c in cols] for r in test]); yt=np.array([r['delta_gap'] for r in test]);
        model=make_pipeline(StandardScaler(),Ridge(alpha=1.)).fit(Xtr,ytr); pred=model.predict(Xt); mse=float(mean_squared_error(yt,pred)); out.setdefault('models',{})[sigset_name]={'pooled_mse':mse,'pooled_corr':corr(pred,yt)}
        out['models'][sigset_name]['by_profile']={}
        for p in KIND:
            tr=[r for r in train if r['profile']==p]; te=[r for r in test if r['profile']==p];
            if not tr or not te: continue
            m=make_pipeline(StandardScaler(),Ridge(alpha=1.)).fit(np.array([[r[c] for c in cols] for r in tr]),np.array([r['delta_gap'] for r in tr])); pp=m.predict(np.array([[r[c] for c in cols] for r in te])); yy=np.array([r['delta_gap'] for r in te]); out['models'][sigset_name]['by_profile'][p]={'mse':float(mean_squared_error(yy,pp)),'corr':corr(pp,yy)}
    out['runtime_sec']=time.time()-t; OUT.write_text(json.dumps(out,indent=2),encoding='utf-8')
    lines=['# Temporal Association Small v1','','## Design','- 4 profiles; train seeds 0–3, held-out seeds 4–7 per profile.','- Window: event −3 through +8.','- Oracle: depth 3, beam 2; primary target is continuous causal Δ optimality gap.','- This avoids unstable binary detection labels when some profiles have few positives.','', '## Pooled signal association']
    for s,v in out['pooled'].items(): lines.append(f"- {s}: Pearson={v['pearson']}, Spearman={v['spearman']}")
    lines += ['', '## Interpretation','- Continuous association is the primary result; binary detection is not trusted when positive counts are sparse.','- Any profile/time slice with near-zero outcome variance is treated as uninformative rather than scored as a failure.','- Oracle depth 3 remains an approximate evaluation target.']
    REPORT.write_text('\n'.join(lines),encoding='utf-8'); print(json.dumps(out,indent=2))
if __name__=='__main__': main()
