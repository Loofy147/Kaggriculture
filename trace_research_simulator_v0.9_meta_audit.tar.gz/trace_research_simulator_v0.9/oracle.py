from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Optional, List, Dict, Any, Sequence
import copy
import math
import statistics

from simulator import ResearchWorld, Scenario, Action, ActionType, WorldTruth, build_greedy_trace


@dataclass
class OracleDecision:
    step: int
    trace_action: Action
    oracle_action: Action
    trace_score: float
    oracle_score: float
    optimality_gap: float
    trace_valid: bool
    trace_obsolete: bool
    repairable: bool
    reason: str


@dataclass
class OracleEpisode:
    decisions: List[OracleDecision]

    @property
    def first_obsolete_step(self) -> Optional[int]:
        for d in self.decisions:
            if d.trace_obsolete:
                return d.step
        return None

    @property
    def first_nonrepairable_step(self) -> Optional[int]:
        for d in self.decisions:
            if not d.repairable:
                return d.step
        return None


def _dist(a, b):
    return abs(a[0]-b[0]) + abs(a[1]-b[1])


def _candidate_actions(world: ResearchWorld, trace_action: Action) -> List[Action]:
    truth = world.ground_truth()
    pos = truth.agent.pos
    candidates = [Action(ActionType.WAIT), trace_action]

    # Collect if immediately available.
    if any(r.available and r.pos == pos for r in truth.resources.values()):
        candidates.append(Action(ActionType.COLLECT, pos))

    # Move one step toward every currently available resource.
    for r in truth.resources.values():
        if not r.available:
            continue
        nxt = world._step_toward(pos, r.pos)
        if nxt != pos:
            candidates.append(Action(ActionType.MOVE, r.pos))

    # Reserve is considered only as a strategic action, not a terminal goal action.
    for r in truth.resources.values():
        if r.available and r.owner is None:
            candidates.append(Action(ActionType.RESERVE, r.pos))

    # Deduplicate while preserving order.
    out = []
    seen = set()
    for a in candidates:
        key = (a.kind.value, a.target)
        if key not in seen:
            seen.add(key)
            out.append(a)
    return out


def _heuristic_after_step(world: ResearchWorld) -> float:
    truth = world.ground_truth()
    if not truth.goal_remaining:
        return 25.0
    # Full-information heuristic: remaining goal value minus travel burden.
    travel = 0
    pos = truth.agent.pos
    remaining = [r for r in truth.resources.values() if r.available and r.pos in truth.goal_remaining]
    if remaining:
        travel = min(_dist(pos, r.pos) for r in remaining)
    return -0.5 * len(truth.goal_remaining) - 0.15 * travel


def score_action(world: ResearchWorld, action: Action) -> float:
    """One-step full-information oracle score + continuation heuristic."""
    branch = copy.deepcopy(world)
    result = branch.step(action)
    # Reward dominates; heuristic breaks ties in favor of preserving future goals.
    return float(result.feedback["reward"]) + _heuristic_after_step(branch)


def decision(
    world: ResearchWorld,
    trace_action: Action,
    valid_epsilon: float = 0.25,
    obsolete_epsilon: float = 1.5,
) -> OracleDecision:
    truth = world.ground_truth()
    scores = []
    for action in _candidate_actions(world, trace_action):
        scores.append((score_action(world, action), action))
    scores.sort(key=lambda x: x[0], reverse=True)
    oracle_score, oracle_action = scores[0]
    trace_score = score_action(world, trace_action)
    gap = oracle_score - trace_score

    trace_valid = gap <= valid_epsilon
    trace_obsolete = gap >= obsolete_epsilon

    # A deviation is repairable if the reference objective remains competitive
    # after allowing a local intervention; obsolete means local repair is no
    # longer close to the full-information best action.
    repairable = gap < obsolete_epsilon
    if trace_obsolete:
        reason = "trace_obsolete"
    elif not trace_valid:
        reason = "trace_degraded_but_repairable"
    else:
        reason = "trace_valid"

    return OracleDecision(
        step=truth.step,
        trace_action=trace_action,
        oracle_action=oracle_action,
        trace_score=trace_score,
        oracle_score=oracle_score,
        optimality_gap=gap,
        trace_valid=trace_valid,
        trace_obsolete=trace_obsolete,
        repairable=repairable,
        reason=reason,
    )


def run_oracle_episode(
    scenario: Scenario,
    valid_epsilon: float = 0.25,
    obsolete_epsilon: float = 1.5,
) -> OracleEpisode:
    world = ResearchWorld(scenario)
    world.reset()
    trace = build_greedy_trace(scenario)
    decisions: List[OracleDecision] = []

    for _ in range(scenario.config.horizon):
        truth = world.ground_truth()
        trace_action = trace[min(truth.step, len(trace)-1)]
        decisions.append(decision(world, trace_action, valid_epsilon, obsolete_epsilon))
        # Advance using the reference trace so oracle validity is measured against
        # the reference trajectory's actual interaction with the world.
        result = world.step(trace_action)
        if result.done:
            break

    return OracleEpisode(decisions)


def summarize(episodes: Sequence[OracleEpisode]) -> Dict[str, Any]:
    first_obs = [e.first_obsolete_step for e in episodes if e.first_obsolete_step is not None]
    first_non = [e.first_nonrepairable_step for e in episodes if e.first_nonrepairable_step is not None]
    gaps = [d.optimality_gap for e in episodes for d in e.decisions]
    return {
        "episodes": len(episodes),
        "obsolete_rate": len(first_obs) / max(1, len(episodes)),
        "repairable_rate": 1.0 - len(first_non) / max(1, len(episodes)),
        "mean_optimality_gap": statistics.mean(gaps) if gaps else 0.0,
        "median_optimality_gap": statistics.median(gaps) if gaps else 0.0,
        "mean_first_obsolete_step": statistics.mean(first_obs) if first_obs else None,
        "mean_first_nonrepairable_step": statistics.mean(first_non) if first_non else None,
    }


def rollout_score(world: ResearchWorld, first_action: Action, depth: int = 3, beam_width: int = 4) -> float:
    """Shallow full-information rollout oracle for delayed effects.

    This is deliberately a research oracle, not an online planner. It uses the
    simulator's full latent state and a small beam to expose delayed consequences
    that a one-step score cannot see.
    """
    if depth <= 0:
        return 0.0
    branch = copy.deepcopy(world)
    result = branch.step(first_action)
    score = float(result.feedback["reward"]) + _heuristic_after_step(branch)
    if depth == 1 or result.done:
        return score

    candidates = _candidate_actions(branch, Action(ActionType.WAIT))
    scored = []
    for action in candidates:
        child = copy.deepcopy(branch)
        r = child.step(action)
        s = float(r.feedback["reward"]) + _heuristic_after_step(child)
        scored.append((s, action, child))
    scored.sort(key=lambda x: x[0], reverse=True)
    best_future = float("-inf")
    for _, action, child in scored[:beam_width]:
        future = rollout_score(child, action, depth=depth-2 if depth > 2 else 1, beam_width=beam_width)
        best_future = max(best_future, future)
    if best_future == float("-inf"):
        best_future = 0.0
    return score + best_future


def rollout_decision(world: ResearchWorld, trace_action: Action, depth: int = 3, beam_width: int = 4,
                     valid_epsilon: float = 0.5, obsolete_epsilon: float = 2.0) -> OracleDecision:
    candidates = _candidate_actions(world, trace_action)
    scored = [(rollout_score(world, a, depth=depth, beam_width=beam_width), a) for a in candidates]
    scored.sort(key=lambda x: x[0], reverse=True)
    oracle_score, oracle_action = scored[0]
    trace_score = rollout_score(world, trace_action, depth=depth, beam_width=beam_width)
    gap = oracle_score - trace_score
    valid = gap <= valid_epsilon
    obsolete = gap >= obsolete_epsilon
    return OracleDecision(
        step=world.ground_truth().step,
        trace_action=trace_action,
        oracle_action=oracle_action,
        trace_score=trace_score,
        oracle_score=oracle_score,
        optimality_gap=gap,
        trace_valid=valid,
        trace_obsolete=obsolete,
        repairable=not obsolete,
        reason=("trace_obsolete" if obsolete else "trace_degraded_but_repairable" if not valid else "trace_valid"),
    )
