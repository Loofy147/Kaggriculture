import os, sys, json, statistics
sys.path.insert(0, os.path.dirname(__file__))
from simulator import ScenarioFactory, WorldConfig
from prediction_targets import matched_target_evaluation, summarize, save_json

profiles=["local","regime","structural","adversarial"]
cfg=WorldConfig(horizon=55)
all_records=[]
for profile in profiles:
    for seed in range(10):
        sc=ScenarioFactory(cfg).make(1000+seed, profile)
        all_records.extend(matched_target_evaluation(sc, profile, horizons=(3,5,10)))
summary=summarize(all_records)
out_dir=os.path.join(os.path.dirname(__file__),"results")
os.makedirs(out_dir,exist_ok=True)
save_json(os.path.join(out_dir,"target_prediction_v0.9.json"),summary)
print(json.dumps(summary,indent=2))
