# Trace Research Simulator v0.1

This is the experimental world intended to become the central evaluation apparatus for the Trace-Driven Reactive Middleware research program.

## Core design

`Scenario -> Hidden Ground Truth World -> Partial Observation -> Agent -> Action -> Environment -> Feedback -> Metrics`

The simulator deliberately keeps **ground truth** separate from **observation** so that we can study belief error, change detection, trace validity, opponent adaptation, and recovery.

## Controlled perturbation families

- `local_block`: temporary local disturbance.
- `regime_change`: dynamics regime changes.
- `resource_removed`: structural change invalidating part of the goal sequence.
- `opponent_adaptation`: opponent behavior becomes responsive to the protagonist.
- `mixed`: combination used for initial interaction testing.

Each perturbation is seeded and parameterized, so experiments can be replayed exactly.

## Initial agent baselines

- `trace_only`
- `trace_reactive`
- `trace_change_aware`
- `trace_opportunistic`

These are intentionally simple. They are controls, not claims about optimality.

## Counterfactual foundation

Every scenario is generated from a stable seed and replayable. The next stage is to add paired counterfactual execution at a chosen decision point so that two architectures can receive the same latent world trajectory and differ only in the intervention decision.

## Important epistemic boundary

The simulator is not evidence that the Trace architecture is better. It is a controlled mechanism for generating evidence for or against that hypothesis.
