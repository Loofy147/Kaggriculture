from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Tuple
import math

from simulator import Observation

@dataclass(frozen=True)
class StateVector:
    step: float
    x: float
    y: float
    visible_resource_count: float
    visible_resource_value: float
    visible_opponent_count: float
    nearest_opponent_distance: float
    blocked_visible_count: float
    future_pressure: float
    vuln: float
    regime_proxy: float
    delta_reward: float = 0.0
    action_failed: float = 0.0

    def as_list(self) -> List[float]:
        return [self.step,self.x,self.y,self.visible_resource_count,self.visible_resource_value,
                self.visible_opponent_count,self.nearest_opponent_distance,self.blocked_visible_count,
                self.future_pressure,self.vuln,self.regime_proxy,self.delta_reward,self.action_failed]

@dataclass
class BeliefState:
    features: Dict[str,float] = field(default_factory=dict)
    deltas: Dict[str,float] = field(default_factory=dict)
    ema: Dict[str,float] = field(default_factory=dict)
    volatility: Dict[str,float] = field(default_factory=dict)
    uncertainty: Dict[str,float] = field(default_factory=dict)
    count: int = 0

class MultiChannelBelief:
    """Observation-only state/belief layer; simulator truth is never inspected."""
    def __init__(self, alpha: float = 0.2, eps: float = 1e-8):
        self.alpha = alpha
        self.eps = eps
        self.reset()

    def reset(self) -> None:
        self.state = BeliefState()
        self._prev: Dict[str,float] = {}
        self._m2: Dict[str,float] = {}

    def _nearest_distance(self, obs: Observation) -> float:
        if not obs.visible_opponents:
            return 20.0
        return float(min(abs(o.pos[0]-obs.agent_pos[0])+abs(o.pos[1]-obs.agent_pos[1])
                         for o in obs.visible_opponents.values()))

    def extract(self, obs: Observation, feedback: Optional[Dict[str,Any]] = None) -> Dict[str,float]:
        fb = feedback or {}
        resources = obs.visible_resources
        values = [float(r.value) for r in resources.values()]
        status = str(fb.get('status','executed'))
        failed = 0.0 if fb.get('executed', True) else 1.0
        return {
            'x': float(obs.agent_pos[0]),
            'y': float(obs.agent_pos[1]),
            'visible_resource_count': float(len(resources)),
            'visible_resource_value': float(sum(values)),
            'visible_opponent_count': float(len(obs.visible_opponents)),
            'nearest_opponent_distance': self._nearest_distance(obs),
            'blocked_visible_count': float(len(obs.blocked_visible)),
            'future_pressure': float(obs.future_resource_pressure),
            'opponent_vulnerability': float(obs.opponent_vulnerability),
            # obs.regime_signal is explicitly excluded: simulator instrumentation.
            'reward': float(fb.get('reward',0.0)),
            'action_failed': failed,
            'status_blocked': float(status == 'blocked'),
            'status_partial': float(status == 'partial'),
            'status_no_resource': float(status == 'no_resource'),
        }

    def update(self, obs: Observation, feedback: Optional[Dict[str,Any]] = None) -> BeliefState:
        f = self.extract(obs, feedback)
        self.state.count += 1
        for k,v in f.items():
            prev = self._prev.get(k, v)
            self.state.deltas[k] = v - prev
            old = self.state.ema.get(k, v)
            ema = self.alpha*v + (1-self.alpha)*old
            self.state.ema[k] = ema
            diff = v - old
            self._m2[k] = self.alpha*(diff*diff) + (1-self.alpha)*self._m2.get(k,0.0)
            self.state.volatility[k] = math.sqrt(max(0.0,self._m2[k]))
            self.state.uncertainty[k] = 1.0 / math.sqrt(max(1,self.state.count))
            self.state.features[k] = v
            self._prev[k] = v
        return self.state

    def channels(self, state: Optional[BeliefState]=None) -> Dict[str,List[float]]:
        s = state or self.state
        channels = {}
        core_keys = ['visible_resource_count','visible_resource_value','visible_opponent_count',
                      'nearest_opponent_distance','blocked_visible_count','future_pressure',
                      'opponent_vulnerability','reward','action_failed']
        for k in core_keys:
            channels[k] = [s.features.get(k,0.0), s.deltas.get(k,0.0), s.volatility.get(k,0.0)]
        return channels

    def fused_features(self) -> Dict[str,float]:
        """Small observation-only feature vector suitable for detector fusion."""
        out = {}
        for k, vals in self.channels().items():
            out[f'{k}:level'] = vals[0]
            out[f'{k}:delta'] = vals[1]
            out[f'{k}:vol'] = vals[2]
        return out
