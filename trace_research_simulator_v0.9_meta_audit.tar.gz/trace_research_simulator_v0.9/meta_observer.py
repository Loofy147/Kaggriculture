from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import List, Dict, Any, Optional
import json
from pathlib import Path

@dataclass
class ExperimentAudit:
    name: str
    question_explicit: bool
    oracle_separated: bool
    causal_alignment: bool
    label_validated: bool
    class_balance_checked: bool
    pooled_metric_risk_checked: bool
    leakage_checked: bool
    train_test_separation: bool
    hidden_confounds_found: List[str]
    corrections_applied: List[str]
    result_status: str
    decision: str
    confidence: str
    notes: str

EXPERIMENTS = [
    ExperimentAudit(
        'v0.3 stress / causal fork', True, True, True, False, True, False, True, False,
        ['event timing initially misaligned', 'observability had not yet been causal', 'magnitude initially partly nominal'],
        ['event-aligned forks', 'causal observability', 'parameter validity checks'],
        'EXPERIMENTALLY_SUPPORTED_LIMITED', 'do not claim architecture superiority', 'medium',
        'Useful world stress test; not yet a definitive architecture comparison.'),
    ExperimentAudit(
        'v0.4 oracle / validity', True, True, True, True, True, True, True, True,
        ['absolute invalidity can precede perturbation', 'one-step oracle misses delayed effects'],
        ['matched clean-vs-perturbed worlds', 'rollout oracle'],
        'EXPERIMENTALLY_SUPPORTED_LIMITED', 'use causal validity rather than raw invalidity', 'medium',
        'Oracle became an explicit research object.'),
    ExperimentAudit(
        'v0.5 validity curves', True, True, True, True, True, True, True, True,
        ['structural/adversarial effects initially too weak'],
        ['stronger perturbations', 'horizon-dependent validity'],
        'EXPERIMENTALLY_SUPPORTED_LIMITED', 'do not equate validity with global optimality', 'medium',
        'Horizon dependence established in this simulator.'),
    ExperimentAudit(
        'v0.6 BOCPD', True, True, True, True, True, True, True, True,
        ['predictive branch bug made change probability collapse to hazard', 'single scalar signal insufficient'],
        ['prior-predictive change branch', 'feature ablation'],
        'CONTRADICTED_SIMPLE_HYPOTHESIS', 'do not connect BOCPD to control yet', 'high',
        'The negative result is one of the stronger methodological findings.'),
    ExperimentAudit(
        'v0.7 belief + BOCPD', True, True, True, True, True, True, True, True,
        ['current observable feature set insufficient', 'high false-alarm rates'],
        ['explicit belief layer'],
        'CONTRADICTED_SIMPLE_HYPOTHESIS', 'build richer state representation', 'high',
        'Combining shallow features did not solve detection.'),
    ExperimentAudit(
        'v0.8 dynamics', True, True, True, True, True, True, True, True,
        ['structural scenario weak', 'instantaneous residuals can be transient'],
        ['stronger structural event', 'persistent residuals'],
        'EXPERIMENTALLY_SUPPORTED_LIMITED', 'use dynamics as fast signal candidate only', 'medium',
        'Profile-dependent signal heterogeneity became explicit.'),
    ExperimentAudit(
        'v0.9 reachability', True, True, True, True, True, True, True, True,
        ['clean objective could already be lost', 'regime has few eligible windows', 'accuracy could be imbalanced'],
        ['objective conditioning', 'Brier/calibration over accuracy'],
        'PRELIMINARY_SUPPORT', 'do not call reachability calibrated/general yet', 'medium-low',
        'Promising but still setup-dependent.'),
    ExperimentAudit(
        'signal selection event-point v1', True, True, True, True, True, True, True, True,
        ['pooled target imbalance', 'profile dominance', 'shallow rollout approximation'],
        ['explicit limitations', 'per-profile follow-up requirement'],
        'PRELIMINARY_SUPPORT', 'dynamics residual is a candidate, not final signal', 'medium-low',
        'Best single event-point discriminator in the tested pooled setup.'),
    ExperimentAudit(
        'temporal confirmatory v1', True, True, False, False, True, True, True, True,
        ['held-out local had zero positives', 'structural had near-zero positives', 'run timed out before completion'],
        ['switched to continuous temporal association on a reduced sample'],
        'INCONCLUSIVE', 'no detector ranking claim', 'low',
        'The binary temporal protocol is underpowered for several profiles.'),
    ExperimentAudit(
        'temporal association small v1', True, True, True, True, True, True, True, True,
        ['very small per-profile n=4', 'pooled associations near zero due heterogeneity/sign cancellation'],
        ['continuous delta-gap target', 'profile/time slice inspection'],
        'INCONCLUSIVE', 'do not select a final signal from pooled correlation', 'low',
        'This run is diagnostic, not confirmatory.'),
]

FUTURE_RULES = [
    'Never trust pooled metrics when profile heterogeneity is plausible; require per-profile results.',
    'Before running a large experiment, validate that the label has sufficient support in every intended evaluation slice.',
    'Treat the oracle as a model with assumptions; test oracle sensitivity to horizon/beam and report it.',
    'Keep latent truth strictly out of online features and detector inputs; audit leakage explicitly.',
    'Verify every parameter is causal before sweeping it; nominal knobs are prohibited from supporting claims.',
    'Separate event onset, delayed consequence, and task-level invalidity; do not use one label for all three.',
    'Use paired counterfactuals whenever comparing perturbation effects.',
    'Require train/test separation whenever a learned threshold, calibration model, or predictor is fitted.',
    'Report class prevalence and minimum positive/negative counts before AUROC/AUPRC claims.',
    'Do not use accuracy as primary evidence under imbalance; include Brier/ECE and prevalence-aware metrics.',
    'When an experiment times out, treat it as a harness finding, not as missing data to silently discard.',
    'Every new architecture claim must state whether it is implementation-correctness, empirical performance, or generalization.',
    'Maintain a hypothesis ledger: successful tests do not upgrade an open hypothesis unless a discriminating comparison was completed.',
    'Add a pre-flight audit before each expensive sweep and a post-run meta-audit before interpretation.',
]

DECISION_RULES = {
    'architecture_change_requires': ['causal evidence or strong comparative evidence', 'reproducible test', 'no unresolved leakage/confound'],
    'detector_admission_requires': ['signal is available online', 'held-out evaluation', 'per-profile stability', 'timing measured', 'false alarms measured'],
    'controller_admission_requires': ['detector validated', 'action effect validated', 'paired counterfactual comparison against baseline', 'safety/constraint checks'],
}

ROOT=Path('/mnt/data/trace_research_simulator_v0.9')
ROOT.joinpath('results/meta_observer_audit_v1.json').write_text(json.dumps({
    'experiments':[asdict(e) for e in EXPERIMENTS],
    'future_rules':FUTURE_RULES,
    'decision_rules':DECISION_RULES,
},indent=2),encoding='utf-8')

md=['# Meta-Environment Observer Audit v1','',
    '## Purpose',
    'This artifact audits not only experiment results but the correctness of our experimental responses: question definition, causal alignment, oracle validity, class support, leakage, and interpretation discipline.','',
    '## Global finding',
    'Our strongest recurring failure mode was not implementation failure; it was **asking a measurement to answer a question it could not see**. Examples: one-step oracle for delayed effects, pooled metrics for heterogeneous profiles, and binary detection labels with too few positives.','',
    '## Experiment audit']
for e in EXPERIMENTS:
    md += [f"### {e.name}", f"- status: **{e.result_status}**", f"- decision: **{e.decision}**", f"- confidence: **{e.confidence}**", f"- hidden confounds: {', '.join(e.hidden_confounds_found) if e.hidden_confounds_found else 'none recorded'}", f"- corrections: {', '.join(e.corrections_applied) if e.corrections_applied else 'none recorded'}", f"- notes: {e.notes}", '']
md += ['## Permanent future rules'] + [f'- {x}' for x in FUTURE_RULES] + ['', '## Admission gates']
for k,v in DECISION_RULES.items(): md += [f'### {k}', *[f'- {x}' for x in v], '']
md += ['## Current research-state decision',
       '- **Do not select a final controller signal yet.**',
       '- Keep `dynamics_residual` as a candidate fast anomaly signal, not a validated detector.',
       '- Keep `objective_reachability` as a candidate task-level signal, not a validated validity probability.',
       '- Require a balanced, per-profile temporal study before connecting any signal to continue/repair/switch/replan.',
       '- The simulator/harness itself is now a first-class research object and must be audited before expensive sweeps.']
ROOT.joinpath('RESEARCH_META_OBSERVER_v1.md').write_text('\n'.join(md),encoding='utf-8')
print('written')
