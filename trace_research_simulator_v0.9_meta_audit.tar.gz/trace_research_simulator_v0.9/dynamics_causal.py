from __future__ import annotations
from pathlib import Path
import copy, json, statistics, sys
sys.path.insert(0, str(Path(__file__).parent))
from simulator import ScenarioFactory, WorldConfig, ResearchWorld, build_greedy_trace
from dynamics import OnlineDynamicsModel

PROFILES=['local','regime','structural','adversarial']
STARTS={'local':12,'regime':28,'structural':18,'adversarial':18}
CHANNELS=['kinematic_residual','reward_residual','status_surprise','resource_disappearance','opponent_approach','opponent_target_pressure']

def make_clean(sc):
    clean=copy.deepcopy(sc)
    clean.perturbations=[]
    return clean

def run(sc, horizon=55):
    w=ResearchWorld(sc); w.reset(); trace=build_greedy_trace(sc); d=OnlineDynamicsModel()
    series={k:[] for k in CHANNELS}
    for t in range(min(horizon,sc.config.horizon)):
        a=trace[t]
        r=w.step(a)
        st=d.update(r.observation,r.feedback,a,a.target)
        for k in CHANNELS: series[k].append(float(st.residuals.get(k,0.0)))
    return series

def paired(profile, seed):
    cfg=WorldConfig(horizon=60,stochasticity=0.03)
    sc=ScenarioFactory(cfg).make(seed,profile)
    pert=run(sc); clean=run(make_clean(sc))
    s=STARTS[profile]
    out={}
    for k in CHANNELS:
        # Window after event, excluding event step itself only for stable comparison.
        pre=max(0,s-3); post=min(cfg.horizon,s+8)
        # compare absolute residual energy
        a=[abs(x) for x in pert[k][pre:post]]
        b=[abs(x) for x in clean[k][pre:post]]
        out[k]={'pert_mean':statistics.mean(a) if a else 0,'clean_mean':statistics.mean(b) if b else 0,
                'delta':(statistics.mean(a)-statistics.mean(b)) if a and b else 0}
    return out

if __name__=='__main__':
    rows=[]
    summary={}
    for p in PROFILES:
        summary[p]={}
        allx={k:[] for k in CHANNELS}
        for seed in range(20):
            o=paired(p,seed)
            for k,v in o.items(): allx[k].append(v['delta'])
            rows.append({'profile':p,'seed':seed,'values':o})
        for k,xs in allx.items():
            summary[p][k]={'mean_delta':statistics.mean(xs),'median_delta':statistics.median(xs),
                           'positive_fraction':sum(v>0 for v in xs)/len(xs)}
    result={'summary':summary,'rows':rows}
    Path('/mnt/data/trace_research_simulator/results/dynamics_causal_v0.8.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(summary,indent=2))
