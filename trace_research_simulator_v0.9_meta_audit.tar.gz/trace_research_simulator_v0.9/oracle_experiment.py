from __future__ import annotations
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent; sys.path.insert(0, str(ROOT))
from simulator import ScenarioFactory, WorldConfig
from oracle import run_oracle_episode, summarize


def main():
    cfg=WorldConfig(width=9,height=9,horizon=60,n_resources=7,n_opponents=1,stochasticity=0.0)
    factory=ScenarioFactory(cfg)
    all_rows={}
    for profile in ['local','regime','structural','adversarial','mixed']:
        episodes=[run_oracle_episode(factory.make(seed,profile)) for seed in range(20)]
        all_rows[profile]=summarize(episodes)
        # event-aligned obsolete timing
        aligned=[]
        for e in episodes:
            if e.first_obsolete_step is not None:
                aligned.append(e.first_obsolete_step)
        all_rows[profile]['obsolete_steps']=aligned
    out=ROOT/'results/oracle_profile_summary.json'
    out.write_text(json.dumps(all_rows,indent=2),encoding='utf-8')
    print(json.dumps(all_rows,indent=2))

if __name__=='__main__': main()
