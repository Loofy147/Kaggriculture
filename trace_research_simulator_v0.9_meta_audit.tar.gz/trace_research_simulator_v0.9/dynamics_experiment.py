from __future__ import annotations
import json, math, statistics
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parent))
from simulator import ScenarioFactory, WorldConfig, ResearchWorld, build_greedy_trace
from dynamics import OnlineDynamicsModel
from bocpd import GaussianBOCPD, GaussianBOCPDConfig

PROFILES = ['local','regime','structural','adversarial']
CHANNELS = {
    'kinematic_residual': lambda d: abs(d.state.residuals.get('kinematic_residual',0.0)),
    'reward_residual': lambda d: abs(d.state.residuals.get('reward_residual',0.0)),
    'status_surprise': lambda d: abs(d.state.residuals.get('status_surprise',0.0)),
    'resource_disappearance': lambda d: abs(d.state.residuals.get('resource_disappearance',0.0)),
    'opponent_approach': lambda d: abs(d.state.residuals.get('opponent_approach',0.0)),
    'opponent_target_pressure': lambda d: abs(d.state.residuals.get('opponent_target_pressure',0.0)),
    'persistent_surprise': lambda d: d.state.persistent.get('surprise_energy', 0.0),
    'persistent_reward': lambda d: d.state.persistent.get('reward_residual', 0.0),
    'persistent_opponent_target': lambda d: d.state.persistent.get('opponent_target_pressure', 0.0),
    'fused': lambda d: d.fused_score(),
}

# For this detector benchmark we define a causal detection target from the scenario's
# known start time. The detector does not receive this target.
STARTS = {'local':12, 'regime':28, 'structural':18, 'adversarial':18}


def run_one(profile, seed, channel):
    cfg = WorldConfig(horizon=60, stochasticity=0.03)
    sc = ScenarioFactory(cfg).make(seed, profile)
    w = ResearchWorld(sc); obs = w.reset(); trace = build_greedy_trace(sc)
    dyn = OnlineDynamicsModel()
    boc = GaussianBOCPD(GaussianBOCPDConfig(hazard_lambda=80.0, max_run_length=60, prior_kappa=1.0))
    probs=[]
    for t in range(cfg.horizon):
        action = trace[min(t, len(trace)-1)]
        res = w.step(action) if t < cfg.horizon else None
        assert res is not None
        obs2, fb = res.observation, res.feedback
        target = trace[min(t, len(trace)-1)].target
        dyn.update(obs2, fb, action, target)
        x = CHANNELS[channel](dyn)
        step = boc.update(float(x))
        probs.append(step.cp_probability)
        obs = obs2
        if res.done: break
    true_start = STARTS[profile]
    threshold = 0.65
    detections = [i for i,p in enumerate(probs) if p >= threshold]
    post = [i for i in detections if i >= true_start]
    delay = (min(post)-true_start) if post else None
    pre_count = sum(1 for i in detections if i < true_start)
    return {'detected': delay is not None, 'delay': delay, 'false_alarm': pre_count>0, 'peak': max(probs) if probs else 0.0}


def summarize(rows):
    out={}
    for profile in PROFILES:
        out[profile]={}
        subset=[r for r in rows if r['profile']==profile]
        for ch in CHANNELS:
            ss=[r for r in subset if r['channel']==ch]
            delays=[r['delay'] for r in ss if r['delay'] is not None]
            out[profile][ch]={
                'detection_rate': sum(r['detected'] for r in ss)/len(ss),
                'false_alarm_rate': sum(r['false_alarm'] for r in ss)/len(ss),
                'mean_delay': statistics.mean(delays) if delays else None,
                'median_peak': statistics.median([r['peak'] for r in ss]) if ss else None,
            }
    return out

if __name__=='__main__':
    rows=[]
    for profile in PROFILES:
        for seed in range(20):
            for ch in CHANNELS:
                rows.append({'profile':profile,'seed':seed,'channel':ch, **run_one(profile, seed, ch)})
    result={'rows':rows,'summary':summarize(rows)}
    p=Path('/mnt/data/trace_research_simulator/results/dynamics_bocpd_v0.8.json')
    p.write_text(json.dumps(result, indent=2))
    print(json.dumps(result['summary'], indent=2))
