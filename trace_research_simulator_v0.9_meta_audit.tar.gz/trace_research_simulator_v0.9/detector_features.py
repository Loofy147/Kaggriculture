from __future__ import annotations

from typing import Any, Dict, Optional
from simulator import Observation, Action


def scalar_observable(obs: Observation, feedback: Optional[Dict[str, Any]], action: Optional[Action]) -> float:
    """Build an observation-only scalar for BOCPD.

    IMPORTANT: this function intentionally excludes `obs.regime_signal` and all perturbation
    metadata because those fields are simulator instrumentation and would leak the label.
    """
    fb = feedback or {}
    reward = float(fb.get("reward", 0.0))
    executed = 1.0 if fb.get("executed", True) else 0.0
    status = str(fb.get("status", "executed"))

    status_penalty = {
        "blocked": -1.0,
        "no_resource": -0.5,
        "reserve_failed": -0.5,
        "partial": -0.25,
        "executed": 0.0,
    }.get(status, 0.0)

    # A stable, low-dimensional signal available to a real agent after execution.
    return reward + 0.5 * executed + status_penalty
