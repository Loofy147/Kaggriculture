from __future__ import annotations
import json, statistics, math, sys
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
from simulator import ScenarioFactory, WorldConfig
from agents import TraceOnlyAgent, ReactiveRepairAgent, ChangeAwareAgent, TriggeredReplanAgent
from counterfactual import paired_counterfactual
FACT={"trace_only":TraceOnlyAgent,"trace_reactive":ReactiveRepairAgent,"trace_change_aware":ChangeAwareAgent,"trace_triggered_replan":TriggeredReplanAgent}

def task(arg):
 p,seed,a,b,fork=arg
 cfg=WorldConfig(width=9,height=9,horizon=60,n_resources=7,n_opponents=1,stochasticity=0.0)
 s=ScenarioFactory(cfg).make(seed,p)
 r=paired_counterfactual(s,{a:FACT[a],b:FACT[b]},fork)
 x=r.branch_metrics[a];y=r.branch_metrics[b]
 return p,a,b,seed,x['reward']-y['reward'],x['collected_goals']-y['collected_goals'],y['collected_goals']-x['collected_goals'],int(x['success'])-int(y['success'])

def main():
 tasks=[]
 for p in ['local','regime','structural','adversarial','mixed']:
  for seed in range(30):
   for a,b in [('trace_reactive','trace_only'),('trace_change_aware','trace_reactive'),('trace_triggered_replan','trace_change_aware')]:
    tasks.append((p,seed,a,b,28))
 with ProcessPoolExecutor(max_workers=8) as ex: rows=list(ex.map(task,tasks,chunksize=4))
 out=[]
 from collections import defaultdict
 D=defaultdict(list)
 for r in rows:D[r[:3]].append(r[4:])
 for k,v in D.items():
  rewards=[x[0] for x in v]
  m=statistics.mean(rewards); ci=1.96*statistics.stdev(rewards)/math.sqrt(len(rewards)) if len(rewards)>1 else 0
  out.append({'profile':k[0],'a':k[1],'b':k[2],'n':len(v),'mean_reward_delta_a_minus_b':m,'ci95_reward_delta':ci,'mean_collected_delta':statistics.mean(x[1] for x in v),'mean_success_delta':statistics.mean(x[3] for x in v)})
 json.dump(out,open(ROOT/'results/paired_counterfactual_sweep.json','w'),indent=2)
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
