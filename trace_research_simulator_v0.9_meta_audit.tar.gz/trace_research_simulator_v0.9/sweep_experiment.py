from __future__ import annotations

import json
import math
import statistics
import sys
from pathlib import Path
from typing import Callable, Dict, List, Tuple

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from simulator import ScenarioFactory, WorldConfig, Scenario, Perturbation
from agents import TraceOnlyAgent, ReactiveRepairAgent, ChangeAwareAgent, OpportunisticAgent, ReplanAgent
from evaluation import run_episode
from counterfactual import paired_counterfactual


FACTORIES = {
    "trace_only": TraceOnlyAgent,
    "trace_reactive": ReactiveRepairAgent,
    "trace_change_aware": ChangeAwareAgent,
    "trace_opportunistic": OpportunisticAgent,
    "trace_replan": ReplanAgent,
}


def build_scenario(cfg: WorldConfig, seed: int, profile: str,
                   magnitude: float, observability: float,
                   opponent_strength: float, regime_multiplier: float) -> Scenario:
    cfg2 = WorldConfig(**cfg.__dict__)
    cfg2.opponent_strength = opponent_strength
    cfg2.regime_move_cost_multiplier = regime_multiplier
    scenario = ScenarioFactory(cfg2).make(seed, profile)
    # Apply controllable perturbation severity/observability consistently.
    patched = []
    for p in scenario.perturbations:
        patched.append(Perturbation(
            kind=p.kind,
            start=p.start,
            duration=p.duration,
            target=p.target,
            magnitude=magnitude,
            observability=observability,
            seed=p.seed,
        ))
    scenario.perturbations = patched
    return scenario


def mean_ci(values: List[float], z: float = 1.96) -> Tuple[float, float]:
    if not values:
        return float('nan'), float('nan')
    mean = statistics.mean(values)
    if len(values) < 2:
        return mean, 0.0
    se = statistics.stdev(values) / math.sqrt(len(values))
    return mean, z * se


def run_factor_sweep(seeds: List[int], profile: str, axis: str, values: List[float]) -> List[dict]:
    base = WorldConfig(width=9, height=9, horizon=60, n_resources=7, n_opponents=1, stochasticity=0.02)
    rows = []
    for value in values:
        by_agent: Dict[str, List[float]] = {k: [] for k in FACTORIES}
        by_success: Dict[str, List[float]] = {k: [] for k in FACTORIES}
        by_cat: Dict[str, List[float]] = {k: [] for k in FACTORIES}
        by_recovery: Dict[str, List[float]] = {k: [] for k in FACTORIES}
        for seed in seeds:
            kwargs = dict(magnitude=1.0, observability=1.0, opponent_strength=0.65, regime_multiplier=2.5)
            kwargs[axis] = value
            scenario = build_scenario(base, seed, profile, **kwargs)
            for name, factory in FACTORIES.items():
                m = run_episode(scenario, factory)
                by_agent[name].append(m.total_reward)
                by_success[name].append(float(m.success))
                by_cat[name].append(float(m.catastrophic_failures))
                by_recovery[name].append(m.recovery_debt)
        for name in FACTORIES:
            mean_r, ci_r = mean_ci(by_agent[name])
            rows.append({
                "profile": profile, "axis": axis, "value": value, "agent": name,
                "n": len(seeds), "mean_reward": mean_r, "ci95_reward": ci_r,
                "success_rate": statistics.mean(by_success[name]),
                "mean_catastrophic_failures": statistics.mean(by_cat[name]),
                "mean_recovery_debt": statistics.mean(by_recovery[name]),
            })
    return rows


def paired_deltas(seeds: List[int], profile: str, a_name: str, b_name: str, fork_step: int = 28) -> dict:
    base = WorldConfig(width=9, height=9, horizon=80, n_resources=7, n_opponents=1, stochasticity=0.0)
    pairwise = []
    for seed in seeds:
        scenario = ScenarioFactory(base).make(seed, profile)
        result = paired_counterfactual(
            scenario,
            {a_name: FACTORIES[a_name], b_name: FACTORIES[b_name]},
            fork_step=fork_step,
        )
        a = result.branch_metrics[a_name]
        b = result.branch_metrics[b_name]
        pairwise.append({
            "seed": seed,
            "reward_delta_a_minus_b": a["reward"] - b["reward"],
            "collected_delta_a_minus_b": a["collected_goals"] - b["collected_goals"],
            "lost_delta_a_minus_b": a["lost_goals"] - b["lost_goals"],
            "success_delta_a_minus_b": int(a["success"]) - int(b["success"]),
        })
    deltas = [x["reward_delta_a_minus_b"] for x in pairwise]
    mean, ci = mean_ci(deltas)
    return {
        "profile": profile,
        "a": a_name,
        "b": b_name,
        "fork_step": fork_step,
        "n": len(deltas),
        "mean_reward_delta_a_minus_b": mean,
        "ci95_reward_delta": ci,
        "mean_collected_delta": statistics.mean(x["collected_delta_a_minus_b"] for x in pairwise),
        "mean_lost_delta": statistics.mean(x["lost_delta_a_minus_b"] for x in pairwise),
        "pairwise": pairwise,
    }


def main() -> None:
    seeds = list(range(24))
    results = {
        "factor_sweeps": [],
        "paired_counterfactuals": [],
        "metadata": {
            "seeds": seeds,
            "profiles": ["local", "regime", "structural", "adversarial", "mixed"],
        },
    }

    # Each axis is varied while others are held fixed.
    axes = [
        ("magnitude", [0.25, 0.5, 1.0, 1.5, 2.0]),
        ("observability", [0.2, 0.4, 0.6, 0.8, 1.0]),
        ("opponent_strength", [0.1, 0.3, 0.5, 0.7, 0.9]),
        ("regime_multiplier", [1.0, 1.5, 2.0, 2.5, 3.5]),
    ]

    for profile in ["local", "regime", "structural", "adversarial"]:
        for axis, values in axes:
            results["factor_sweeps"].extend(run_factor_sweep(seeds, profile, axis, values))

    for profile in ["local", "regime", "structural", "adversarial", "mixed"]:
        for a, b in [("trace_reactive", "trace_only"), ("trace_change_aware", "trace_reactive"), ("trace_replan", "trace_change_aware")]:
            results["paired_counterfactuals"].append(paired_deltas(seeds[:24], profile, a, b))

    out = ROOT / "results"
    out.mkdir(exist_ok=True)
    with (out / "stress_sweep.json").open("w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)

    # Compact summary for human review.
    summary = []
    for r in results["factor_sweeps"]:
        if r["value"] in {0.2, 0.5, 1.0, 1.5, 2.0, 0.9, 3.5}:  # compact selection; full raw data above
            summary.append(r)
    with (out / "stress_sweep_summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print("Wrote", out / "stress_sweep.json")


if __name__ == "__main__":
    main()
