from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple
import math

from simulator import Observation, Action, ActionType

Pos = Tuple[int, int]


def manhattan(a: Pos, b: Pos) -> float:
    return float(abs(a[0]-b[0]) + abs(a[1]-b[1]))


def expected_step(src: Pos, target: Optional[Pos]) -> Pos:
    if target is None:
        return src
    x, y = src
    tx, ty = target
    if x < tx: return (x+1, y)
    if x > tx: return (x-1, y)
    if y < ty: return (x, y+1)
    if y > ty: return (x, y-1)
    return src

@dataclass
class DynamicsState:
    count: int = 0
    predicted_next_pos: Optional[Pos] = None
    trace_target: Optional[Pos] = None
    trace_progress_expected: float = 0.0
    trace_progress_observed: float = 0.0
    features: Dict[str, float] = field(default_factory=dict)
    ema: Dict[str, float] = field(default_factory=dict)
    volatility: Dict[str, float] = field(default_factory=dict)
    residuals: Dict[str, float] = field(default_factory=dict)
    persistent: Dict[str, float] = field(default_factory=dict)
    history: List[Dict[str, float]] = field(default_factory=list)

class OnlineDynamicsModel:
    """Observation-only online predictor.

    It estimates deviations between what the current action/trace implies and
    what the agent actually observes. It never reads simulator truth.
    """
    def __init__(self, alpha: float = 0.2, history_limit: int = 256):
        self.alpha = alpha
        self.history_limit = history_limit
        self.reset()

    def reset(self) -> None:
        self.state = DynamicsState()
        self._prev_obs: Optional[Observation] = None
        self._prev_feedback: Optional[Dict[str, Any]] = None
        self._prev_resources: Dict[int, Pos] = {}
        self._prev_opponents: Dict[str, Pos] = {}
        self._reward_baseline: Dict[str, float] = {}
        self._reward_var: Dict[str, float] = {}

    def _action_key(self, action: Optional[Action]) -> str:
        if action is None:
            return 'NONE'
        return action.kind.value

    def _update_ema(self, key: str, value: float) -> None:
        old = self.state.ema.get(key, value)
        ema = self.alpha * value + (1.0-self.alpha) * old
        self.state.ema[key] = ema
        diff = value - old
        self.state.volatility[key] = math.sqrt(
            max(0.0, self.alpha * diff * diff + (1.0-self.alpha) * self.state.volatility.get(key, 0.0) ** 2)
        )

    def _reward_residual(self, action: Optional[Action], reward: float) -> float:
        key = self._action_key(action)
        baseline = self._reward_baseline.get(key, reward)
        var = self._reward_var.get(key, 0.0)
        residual = reward - baseline
        # Online baseline/variance update.
        self._reward_baseline[key] = self.alpha * reward + (1.0-self.alpha) * baseline
        self._reward_var[key] = self.alpha * residual * residual + (1.0-self.alpha) * var
        scale = math.sqrt(max(var, 1e-6))
        return residual / max(scale, 0.25)

    def update(self, obs: Observation, feedback: Optional[Dict[str, Any]], action: Optional[Action], trace_target: Optional[Pos]) -> DynamicsState:
        fb = feedback or {}
        reward = float(fb.get('reward', 0.0))
        self.state.count += 1

        # 1) Kinematic prediction residual: what action should have done vs observed.
        pred_pos = expected_step(self._prev_obs.agent_pos if self._prev_obs else obs.agent_pos,
                                 action.target if action and action.kind == ActionType.MOVE else None)
        kin_res = manhattan(pred_pos, obs.agent_pos) if self._prev_obs else 0.0

        # 2) Action outcome surprise: failed/blocked/partial execution.
        status = str(fb.get('status', 'executed'))
        status_surprise = {
            'blocked': 1.0, 'partial': 0.75, 'no_resource': 0.6,
            'reserve_failed': 0.6, 'executed': 0.0,
        }.get(status, 0.5 if status != 'executed' else 0.0)

        # 3) Reward dynamics residual relative to action-conditioned baseline.
        reward_res = self._reward_residual(action, reward) if self.state.count > 2 else 0.0

        # 4) Trace progress residual: progress toward target vs realized progress.
        trace_progress = 0.0
        if trace_target is not None:
            prev_pos = self._prev_obs.agent_pos if self._prev_obs else obs.agent_pos
            before = manhattan(prev_pos, trace_target)
            after = manhattan(obs.agent_pos, trace_target)
            trace_progress = before - after

        # 5) Resource pressure dynamics: changes in visible inventory/count and value.
        res_count = float(len(obs.visible_resources))
        res_value = float(sum(r.value for r in obs.visible_resources.values()))
        prev_res_count = float(len(self._prev_resources)) if self._prev_obs is not None else res_count
        resource_disappearance = max(0.0, prev_res_count - res_count)

        # 6) Opponent relative motion/acceleration and target pressure.
        opp_speed = 0.0
        opp_approach = 0.0
        opp_target_pressure = 0.0
        if self._prev_obs is not None and obs.visible_opponents:
            speeds = []
            approaches = []
            target_dist_gaps = []
            target = trace_target
            for name, o in obs.visible_opponents.items():
                prev = self._prev_opponents.get(name)
                if prev is not None:
                    d0 = manhattan(prev, self._prev_obs.agent_pos)
                    d1 = manhattan(o.pos, obs.agent_pos)
                    speeds.append(manhattan(prev, o.pos))
                    approaches.append(d0 - d1)
                if target is not None:
                    agent_d = manhattan(obs.agent_pos, target)
                    opp_d = manhattan(o.pos, target)
                    target_dist_gaps.append(agent_d - opp_d)
            if speeds:
                opp_speed = sum(speeds) / len(speeds)
            if approaches:
                opp_approach = sum(approaches) / len(approaches)
            if target_dist_gaps:
                opp_target_pressure = max(target_dist_gaps)

        features = {
            'kinematic_residual': float(kin_res),
            'status_surprise': float(status_surprise),
            'reward_residual': float(max(-10.0, min(10.0, reward_res))),
            'trace_progress': float(trace_progress),
            'resource_disappearance': float(resource_disappearance),
            'visible_resource_count': res_count,
            'visible_resource_value': res_value,
            'opponent_speed': float(opp_speed),
            'opponent_approach': float(opp_approach),
            'opponent_target_pressure': float(max(-20.0, min(20.0, opp_target_pressure))),
            'opponent_distance': float(min(
                [manhattan(o.pos, obs.agent_pos) for o in obs.visible_opponents.values()]
                or [20.0]
            )),
            'blocked_visible_count': float(len(obs.blocked_visible)),
        }
        residuals = {
            'kinematic_residual': features['kinematic_residual'],
            'reward_residual': features['reward_residual'],
            'status_surprise': features['status_surprise'],
            # Larger positive resource disappearance is surprising under persistence.
            'resource_disappearance': features['resource_disappearance'],
            # Positive approach means opponent got closer in relative terms.
            'opponent_approach': features['opponent_approach'],
            'opponent_target_pressure': max(0.0, features['opponent_target_pressure']),
        }
        for k, v in features.items():
            self._update_ema(k, v)
        for k, v in residuals.items():
            self.state.residuals[k] = v
            old_p = self.state.persistent.get(k, 0.0)
            # Persistence is an observation-derived memory, not an oracle signal.
            self.state.persistent[k] = self.alpha * abs(v) + (1.0-self.alpha) * old_p

        # Composite persistence: useful for change detectors that need evidence
        # extending beyond a single failed execution.
        weights = {
            'kinematic_residual': 1.0,
            'reward_residual': 1.0,
            'status_surprise': 1.0,
            'resource_disappearance': 0.8,
            'opponent_approach': 0.5,
            'opponent_target_pressure': 0.8,
        }
        denom = sum(weights.values())
        self.state.persistent['surprise_energy'] = sum(
            weights[k] * self.state.persistent.get(k, 0.0) for k in weights
        ) / denom

        self.state.features = dict(features)
        self.state.trace_target = trace_target
        self.state.predicted_next_pos = pred_pos
        self.state.trace_progress_observed = trace_progress
        self.state.history.append(dict(features))
        if len(self.state.history) > self.history_limit:
            self.state.history.pop(0)

        self._prev_obs = obs
        self._prev_feedback = dict(fb)
        self._prev_resources = {rid: r.pos for rid, r in obs.visible_resources.items()}
        self._prev_opponents = {name: o.pos for name, o in obs.visible_opponents.items()}
        return self.state

    def detector_channels(self) -> Dict[str, float]:
        out = dict(self.state.residuals)
        out.update({f'persistent:{k}': v for k, v in self.state.persistent.items()})
        return out

    def fused_score(self, weights: Optional[Dict[str, float]] = None) -> float:
        weights = weights or {
            'kinematic_residual': 1.0,
            'reward_residual': 0.8,
            'status_surprise': 1.0,
            'resource_disappearance': 0.8,
            'opponent_approach': 0.5,
            'opponent_target_pressure': 0.8,
        }
        vals = []
        ws = []
        for k, w in weights.items():
            vals.append(abs(self.state.residuals.get(k, 0.0)))
            ws.append(abs(w))
        return sum(v*w for v,w in zip(vals, ws)) / max(sum(ws), 1e-9)
