# Trace Research Simulator v0.8

Research environment for testing Trace-Driven Reactive Middleware hypotheses.

Core separation:

```text
WORLD TRUTH (oracle only)
        |
        v
PARTIAL OBSERVATION
        |
        v
STATE / BELIEF
        |
        v
DYNAMICS / PREDICTION RESIDUALS
        |
        v
CHANGE DETECTOR (currently BOCPD as detector-only)
        |
        v
VALIDITY / REPAIR / REPLAN (not yet coupled)
```

The current milestone deliberately stops before allowing the detector to control the agent. This preserves causal attribution.

## Main modules

- `simulator.py` — controlled world and perturbation generator
- `oracle.py`, `validity.py` — full-information evaluation only
- `belief.py` — observation-only belief features
- `dynamics.py` — online prediction/residual layer
- `bocpd.py` — corrected Gaussian BOCPD
- `dynamics_experiment.py` — detector benchmark
- `dynamics_causal.py` — matched clean-vs-perturbed comparison

## Verification
23/23 tests pass in the v0.8 test suite.
