from __future__ import annotations
from pathlib import Path
import json, statistics, math, sys, copy
ROOT=Path(__file__).resolve().parent; sys.path.insert(0,str(ROOT))
from simulator import ScenarioFactory, WorldConfig, ResearchWorld, build_greedy_trace
from oracle import rollout_decision

FORKS={'local':12,'regime':28,'structural':40,'adversarial':22}

def make_clean(s):
 c=copy.deepcopy(s); c.perturbations=[]; return c

def advance(w, trace, fork):
 w.reset()
 for _ in range(fork):
  w.step(trace[w.ground_truth().step])

def one(seed, profile):
 cfg=WorldConfig(width=9,height=9,horizon=60,n_resources=7,n_opponents=1,stochasticity=0.0)
 s=ScenarioFactory(cfg).make(seed,profile); c=make_clean(s); fork=FORKS[profile]
 wp,wc=ResearchWorld(s),ResearchWorld(c); tp,tc=build_greedy_trace(s),build_greedy_trace(c)
 advance(wp,tp,fork); advance(wc,tc,fork)
 dp=rollout_decision(wp,tp[fork],depth=3,beam_width=3)
 dc=rollout_decision(wc,tc[fork],depth=3,beam_width=3)
 return {'seed':seed,'profile':profile,'delta_gap':dp.optimality_gap-dc.optimality_gap,
         'perturbed_gap':dp.optimality_gap,'clean_gap':dc.optimality_gap,
         'perturbed_obsolete':dp.trace_obsolete,'clean_obsolete':dc.trace_obsolete,
         'causal_switch':dp.trace_obsolete and not dc.trace_obsolete}

def main():
 out={}
 for p in FORKS:
  rs=[one(seed,p) for seed in range(30)]
  d=[r['delta_gap'] for r in rs]
  out[p]={
    'n':len(rs),'mean_delta_gap':statistics.mean(d),
    'ci95_delta_gap':1.96*statistics.stdev(d)/math.sqrt(len(d)) if len(d)>1 else 0,
    'obsolete_rate_perturbed':statistics.mean(r['perturbed_obsolete'] for r in rs),
    'obsolete_rate_clean':statistics.mean(r['clean_obsolete'] for r in rs),
    'causal_obsolete_switch_rate':statistics.mean(r['causal_switch'] for r in rs),
  }
 (ROOT/'results/oracle_rollout_causal_profiles.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
