from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import List, Dict, Optional, Sequence, Tuple, Any
import copy
import json
import statistics

from simulator import ResearchWorld, Scenario, Action, ActionType, build_greedy_trace
from oracle import _candidate_actions, _heuristic_after_step


@dataclass
class ValidityPoint:
    step: int
    horizon: int
    trace_value: float
    best_value: float
    optimality_gap: float
    valid: bool
    degraded: bool
    obsolete: bool
    repairable: bool
    best_action_changed: bool
    event_kinds: List[str]


@dataclass
class CausalPoint:
    step: int
    horizon: int
    profile: str
    gap_clean: float
    gap_perturbed: float
    delta_gap: float
    validity_changed: bool
    objective_changed: bool
    event_kinds: List[str]


@dataclass
class EpisodeValidity:
    scenario_id: str
    points: List[ValidityPoint]

    @property
    def first_obsolete_step(self) -> Optional[int]:
        for p in self.points:
            if p.obsolete:
                return p.step
        return None


# The simulator's task objective is implicitly encoded by its reward function.
# This module therefore treats "objective change" as a *decision-landscape change*
# rather than claiming the formal reward function itself changed.
def _score_one(world: ResearchWorld, action: Action) -> float:
    branch = copy.deepcopy(world)
    result = branch.step(action)
    return float(result.feedback["reward"]) + _heuristic_after_step(branch)


def trace_value(world: ResearchWorld, trace: Sequence[Action], start_step: int, horizon: int) -> float:
    branch = copy.deepcopy(world)
    total = 0.0
    for k in range(max(0, horizon)):
        if branch.ground_truth().step >= branch.scenario.config.horizon:
            break
        idx = min(start_step + k, len(trace) - 1)
        result = branch.step(trace[idx])
        total += float(result.feedback["reward"])
        if result.done:
            break
    return total + _heuristic_after_step(branch)


def _beam_rollout(world: ResearchWorld, trace_action: Action, horizon: int, beam_width: int = 3) -> Tuple[float, Action]:
    # Beam nodes are (score, first_action, world).
    candidates = _candidate_actions(world, trace_action)
    beam: List[Tuple[float, Action, ResearchWorld]] = []
    for action in candidates:
        branch = copy.deepcopy(world)
        result = branch.step(action)
        score = float(result.feedback["reward"])
        beam.append((score, action, branch))
    beam.sort(key=lambda x: x[0], reverse=True)
    beam = beam[: max(1, beam_width)]

    if horizon <= 1:
        best = max(beam, key=lambda x: x[0] + _heuristic_after_step(x[2]))
        return best[0] + _heuristic_after_step(best[2]), best[1]

    for _ in range(1, horizon):
        expanded: List[Tuple[float, Action, ResearchWorld]] = []
        for cumulative, first_action, node in beam:
            for action in _candidate_actions(node, Action(ActionType.WAIT)):
                child = copy.deepcopy(node)
                result = child.step(action)
                value = cumulative + float(result.feedback["reward"])
                expanded.append((value, first_action, child))
        expanded.sort(key=lambda x: x[0] + _heuristic_after_step(x[2]), reverse=True)
        beam = expanded[: max(1, beam_width)]
        if not beam:
            break

    best = max(beam, key=lambda x: x[0] + _heuristic_after_step(x[2]))
    return best[0] + _heuristic_after_step(best[2]), best[1]


def _trace_action_at(world: ResearchWorld, trace: Sequence[Action]) -> Action:
    step = world.ground_truth().step
    return trace[min(step, len(trace) - 1)]


def compute_validity_curve(
    scenario: Scenario,
    horizons: Sequence[int] = (1, 3, 5),
    beam_width: int = 3,
    valid_epsilon: float = 0.5,
    obsolete_epsilon: float = 2.0,
) -> EpisodeValidity:
    world = ResearchWorld(scenario)
    world.reset()
    trace = build_greedy_trace(scenario)
    points: List[ValidityPoint] = []

    for _ in range(scenario.config.horizon):
        truth = world.ground_truth()
        if truth.step >= len(trace):
            break
        trace_action = _trace_action_at(world, trace)
        events = [p.kind for p in truth.perturbations if p.active(truth.step)]

        for h in horizons:
            tv = trace_value(world, trace, truth.step, h)
            best, best_action = _beam_rollout(world, trace_action, h, beam_width)
            gap = max(0.0, best - tv)
            valid = gap <= valid_epsilon
            obsolete = gap >= obsolete_epsilon
            degraded = not valid and not obsolete
            repairable = not obsolete
            points.append(ValidityPoint(
                step=truth.step,
                horizon=int(h),
                trace_value=tv,
                best_value=best,
                optimality_gap=gap,
                valid=valid,
                degraded=degraded,
                obsolete=obsolete,
                repairable=repairable,
                best_action_changed=(best_action != trace_action),
                event_kinds=events,
            ))

        world.step(trace_action)
        if world.ground_truth().step >= scenario.config.horizon:
            break

    return EpisodeValidity(scenario.scenario_id, points)


def _world_at_step(scenario: Scenario, step: int, use_trace: bool = True) -> ResearchWorld:
    world = ResearchWorld(scenario)
    world.reset()
    trace = build_greedy_trace(scenario)
    for _ in range(step):
        if use_trace:
            world.step(trace[min(world.ground_truth().step, len(trace)-1)])
        else:
            break
    return world


def clean_scenario_for_profile(scenario: Scenario, profile: str) -> Scenario:
    clone = copy.deepcopy(scenario)
    clone.perturbations = [p for p in clone.perturbations if p.kind != profile]
    return clone


def causal_validity_curve(
    scenario: Scenario,
    event_kind: str,
    horizons: Sequence[int] = (1, 3, 5),
    window: int = 3,
    beam_width: int = 3,
    valid_epsilon: float = 0.5,
    obsolete_epsilon: float = 2.0,
) -> List[CausalPoint]:
    events = [p for p in scenario.perturbations if p.kind == event_kind]
    if not events:
        return []
    start = events[0].start
    steps = list(range(max(0, start - window), min(scenario.config.horizon - 1, start + window) + 1))

    clean = clean_scenario_for_profile(scenario, event_kind)
    clean_world = ResearchWorld(clean)
    clean_world.reset()
    pert_world = ResearchWorld(scenario)
    pert_world.reset()
    trace = build_greedy_trace(scenario)
    out: List[CausalPoint] = []

    for step in range(scenario.config.horizon):
        clean_truth = clean_world.ground_truth()
        pert_truth = pert_world.ground_truth()
        if step in steps and clean_truth.step == pert_truth.step:
            for h in horizons:
                action_c = trace_value(clean_world, trace, step, h)
                best_c, best_action_c = _beam_rollout(clean_world, trace[min(step, len(trace)-1)], h, beam_width)
                gap_c = max(0.0, best_c - action_c)

                action_p = trace_value(pert_world, trace, step, h)
                best_p, best_action_p = _beam_rollout(pert_world, trace[min(step, len(trace)-1)], h, beam_width)
                gap_p = max(0.0, best_p - action_p)

                validity_changed = (gap_c <= valid_epsilon) != (gap_p <= valid_epsilon)
                objective_changed = (best_action_c != best_action_p) or abs(gap_p - gap_c) > valid_epsilon
                active = [p.kind for p in pert_truth.perturbations if p.active(step)]
                out.append(CausalPoint(
                    step=step,
                    horizon=int(h),
                    profile=event_kind,
                    gap_clean=gap_c,
                    gap_perturbed=gap_p,
                    delta_gap=gap_p - gap_c,
                    validity_changed=validity_changed,
                    objective_changed=objective_changed,
                    event_kinds=active,
                ))
        clean_world.step(trace[min(step, len(trace)-1)])
        pert_world.step(trace[min(step, len(trace)-1)])

    return out


def summarize_curves(curves: Sequence[EpisodeValidity]) -> Dict[str, Any]:
    all_points = [p for e in curves for p in e.points]
    by_h: Dict[str, Dict[str, Any]] = {}
    for h in sorted({p.horizon for p in all_points}):
        pts = [p for p in all_points if p.horizon == h]
        by_h[str(h)] = {
            "points": len(pts),
            "mean_gap": statistics.mean(p.optimality_gap for p in pts) if pts else 0.0,
            "obsolete_rate": statistics.mean(1.0 if p.obsolete else 0.0 for p in pts) if pts else 0.0,
            "degraded_rate": statistics.mean(1.0 if p.degraded else 0.0 for p in pts) if pts else 0.0,
            "repairable_rate": statistics.mean(1.0 if p.repairable else 0.0 for p in pts) if pts else 0.0,
            "action_change_rate": statistics.mean(1.0 if p.best_action_changed else 0.0 for p in pts) if pts else 0.0,
        }
    return {"episodes": len(curves), "by_horizon": by_h}


def save_json(path: str, payload: Any) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, default=asdict)
