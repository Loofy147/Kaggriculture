from __future__ import annotations
import copy, json, math, statistics, time
from pathlib import Path
import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss

from simulator import ScenarioFactory, WorldConfig, ResearchWorld, build_greedy_trace
from dynamics import OnlineDynamicsModel
from prediction_targets import OnlineTracePredictor, predict_reachability
from oracle import rollout_decision

ROOT=Path('/mnt/data/trace_research_simulator_v0.9')
OUT=ROOT/'results/temporal_signal_confirmatory_v1.json'
REPORT=ROOT/'RESEARCH_REPORT_temporal_confirmatory_v1.md'
KIND={'local':'local_block','regime':'regime_change','structural':'structural_block','adversarial':'opponent_intercept'}
SIGNALS=['reward_residual','dynamics_residual','trace_deviation','objective_reachability']


def safe_auc(y,p,fn):
    return None if len(set(y))<2 else float(fn(y,p))

def ece(y,p,bins=10):
    y=np.asarray(y); p=np.asarray(p); out=0.0
    edges=np.linspace(0,1,bins+1)
    for lo,hi in zip(edges[:-1],edges[1:]):
        m=(p>=lo)&(p<(hi if hi<1 else hi+1e-9))
        if m.any(): out += float(m.mean())*abs(float(y[m].mean())-float(p[m].mean()))
    return float(out)

def run_episode(profile,seed,cfg,pre=3,post=8,roll_depth=3):
    fac=ScenarioFactory(cfg); sc=fac.make(seed,profile); trace=build_greedy_trace(sc); event_kind=KIND[profile]
    event_start=min(p.start for p in sc.perturbations if p.kind==event_kind)
    clean=copy.deepcopy(sc); clean.perturbations=[p for p in clean.perturbations if p.kind!=event_kind]
    cw=ResearchWorld(clean); pw=ResearchWorld(sc); cw.reset(); pw.reset()
    dyn=OnlineDynamicsModel(alpha=0.2); pred=OnlineTracePredictor(cfg.move_cost,cfg.wait_cost)
    rows=[]; prev_a=None; prev_fb=None
    start=max(0,event_start-pre); stop=min(cfg.horizon-1,event_start+post)
    for step in range(stop+1):
        co,po=cw.observe(),pw.observe(); a=trace[min(step,len(trace)-1)]
        if step>=start:
            dyn.update(po,prev_fb,prev_a,a.target)
            ch=dyn.detector_channels()
            reward=abs(float(ch.get('reward_residual',0.0)))
            dynv=float(np.mean([abs(ch.get(k,0.0)) for k in ('kinematic_residual','status_surprise','resource_disappearance','opponent_approach','opponent_target_pressure')]))
            clean_pos=cw.ground_truth().agent.pos
            dev=float(abs(po.agent_pos[0]-clean_pos[0])+abs(po.agent_pos[1]-clean_pos[1]))
            reach=1.0-predict_reachability(po,a.target,5,pred).predicted_probability
            # Shallow rollout causal oracle at this exact point, same history/fork.
            dc=rollout_decision(cw,a,depth=roll_depth,beam_width=2)
            dp=rollout_decision(pw,a,depth=roll_depth,beam_width=2)
            delta=float(dp.optimality_gap-dc.optimality_gap)
            label=int(delta>=0.05 or (dp.trace_obsolete and not dc.trace_obsolete))
            rows.append({'profile':profile,'seed':seed,'step':step,'rel_step':step-event_start,'event_start':event_start,
                         'label':label,'delta_gap':delta,'clean_obsolete':int(dc.trace_obsolete),'pert_obsolete':int(dp.trace_obsolete),
                         'reward_residual':reward,'dynamics_residual':dynv,'trace_deviation':dev,'objective_reachability':reach})
        cr=cw.step(a); pr=pw.step(a); prev_a=a; prev_fb=pr.feedback
        prog=1.0 if pr.truth.agent.pos!=po.agent_pos or (a.kind.name=='COLLECT' and pr.feedback.get('status') in {'executed','partial'}) else 0.0
        pred.update(float(pr.feedback.get('reward',0.0)),prog,pr.feedback.get('status') not in {'executed','partial'})
        if cr.done or pr.done: break
    return rows

def fit_and_score(train,test,cols):
    Xtr=np.array([[r[c] for c in cols] for r in train]); ytr=np.array([r['label'] for r in train])
    Xt=np.array([[r[c] for c in cols] for r in test]); yt=np.array([r['label'] for r in test])
    if len(set(ytr))<2:
        return {'error':'training has one class'}
    clf=make_pipeline(StandardScaler(),LogisticRegression(max_iter=1000,class_weight='balanced')).fit(Xtr,ytr)
    p=clf.predict_proba(Xt)[:,1]
    return {'auroc':safe_auc(yt,p,roc_auc_score),'auprc':safe_auc(yt,p,average_precision_score),'brier':float(brier_score_loss(yt,p)),'ece':ece(yt,p)}

def delay_metrics(test_rows,model,cols,threshold=0.5):
    # Rebuild episode-level predictions.
    out=[]; false_pre=[]; delays=[]; misses=[]
    for seed in sorted(set(r['seed'] for r in test_rows)):
        rr=sorted([r for r in test_rows if r['seed']==seed], key=lambda x:x['step'])
        if not rr: continue
        X=np.array([[r[c] for c in cols] for r in rr]); p=model.predict_proba(X)[:,1]
        event=min(r['event_start'] for r in rr)
        pred_steps=[rr[i]['step'] for i,v in enumerate(p) if v>=threshold]
        true_steps=[r['step'] for r in rr if r['label']==1]
        pre_pred=[s for s in pred_steps if s<event]
        false_pre.append(len(pre_pred)>0)
        if true_steps:
            first_true=min(true_steps)
            after=[s for s in pred_steps if s>=event]
            if after: delays.append(after[0]-first_true)
            else: misses.append(1)
        elif pred_steps:
            misses.append(1)
    return {'episodes':len(set(r['seed'] for r in test_rows)),'mean_delay':None if not delays else float(statistics.mean(delays)),'median_delay':None if not delays else float(statistics.median(delays)),'miss_rate':float(len(misses)/max(1,len(delays)+len(misses))),'pre_event_false_alarm_rate':float(sum(false_pre)/max(1,len(false_pre)))}

def main():
    t0=time.time(); cfg=WorldConfig(horizon=55)
    train=[]; test=[]; per_profile={}
    for profile in KIND:
        for seed in range(0,12): train += run_episode(profile,seed,cfg)
        for seed in range(12,24): test += run_episode(profile,seed,cfg)
        trp=[r for r in train if r['profile']==profile]; tep=[r for r in test if r['profile']==profile]
        per_profile[profile]={'train_rows':len(trp),'test_rows':len(tep),'train_positive':sum(r['label'] for r in trp),'test_positive':sum(r['label'] for r in tep)}
        print(profile,per_profile[profile],flush=True)
    cols_by={'reward_residual':['reward_residual'],'dynamics_residual':['dynamics_residual'],'trace_deviation':['trace_deviation'],'objective_reachability':['objective_reachability'],'combined':SIGNALS}
    models={}; delay={}
    # Fit pooled balanced-by-profile with equal weight achieved via downsampling not possible directly; use class weights and report per profile separately.
    for name,cols in cols_by.items():
        Xtr=np.array([[r[c] for c in cols] for r in train]); ytr=np.array([r['label'] for r in train]);
        Xt=np.array([[r[c] for c in cols] for r in test]); yt=np.array([r['label'] for r in test])
        clf=make_pipeline(StandardScaler(),LogisticRegression(max_iter=1000,class_weight='balanced')).fit(Xtr,ytr)
        p=clf.predict_proba(Xt)[:,1]
        models[name]={'pooled':{'auroc':safe_auc(yt,p,roc_auc_score),'auprc':safe_auc(yt,p,average_precision_score),'brier':float(brier_score_loss(yt,p)),'ece':ece(yt,p)}}
        delay[name]=delay_metrics(test,clf,cols)
        models[name]['per_profile']={}
        for profile in KIND:
            trp=[r for r in train if r['profile']==profile]; tep=[r for r in test if r['profile']==profile]
            if len(set(r['label'] for r in trp))<2 or len(set(r['label'] for r in tep))<2:
                models[name]['per_profile'][profile]={'auroc':None,'auprc':None,'brier':None,'note':'one class in split'}
                continue
            pprof=clf.predict_proba(np.array([[r[c] for c in cols] for r in tep]))[:,1]; yprof=np.array([r['label'] for r in tep])
            models[name]['per_profile'][profile]={'auroc':safe_auc(yprof,pprof,roc_auc_score),'auprc':safe_auc(yprof,pprof,average_precision_score),'brier':float(brier_score_loss(yprof,pprof))}
    payload={'study':'temporal_signal_confirmatory_v1','n_train_rows':len(train),'n_test_rows':len(test),'window':[-3,8],'rollout_depth':3,'models':models,'delay':delay,'per_profile_counts':per_profile,'runtime_sec':time.time()-t0}
    OUT.write_text(json.dumps(payload,indent=2),encoding='utf-8')
    # concise report
    lines=['# Temporal Signal Confirmatory Study v1','',f"Runtime: {payload['runtime_sec']:.1f}s",'', '## Design','- 4 profiles; train seeds 0–11; held-out test seeds 12–23 per profile.','- Temporal window: event start −3 through +8 steps.','- Oracle label: depth-3 rollout, beam width 2; causal harm if Δgap ≥ 0.05 or obsolete flip.','- Same clean/perturbed history and same seed per episode.','- Oracle fields are evaluation-only.','', '## Results']
    for name,res in models.items():
        m=res['pooled']; d=delay[name]
        lines.append(f"### {name}")
        lines.append(f"- pooled AUROC={m['auroc']}, AUPRC={m['auprc']}, Brier={m['brier']}, ECE={m['ece']}")
        lines.append(f"- mean detection delay={d['mean_delay']}, median={d['median_delay']}, miss rate={d['miss_rate']}, pre-event false-alarm rate={d['pre_event_false_alarm_rate']}")
        for p,v in res['per_profile'].items(): lines.append(f"- {p}: AUROC={v['auroc']}, AUPRC={v['auprc']}, Brier={v['brier']}")
    lines += ['', '## Epistemic interpretation','- This is a confirmatory study of temporal usefulness, not evidence of generalization.','- Pooled scores must not override profile-specific failures.','- Detection delay is measured relative to the first oracle-positive row in the observed window, not the true latent regime-change time.','- Oracle depth-3 remains an approximation; it is not global optimality.']
    REPORT.write_text('\n'.join(lines),encoding='utf-8')
    print(json.dumps(payload,indent=2))
if __name__=='__main__': main()
