from __future__ import annotations
from pathlib import Path
import json, statistics, math, sys
ROOT=Path(__file__).resolve().parent; sys.path.insert(0,str(ROOT))
from simulator import ScenarioFactory, WorldConfig, ResearchWorld, build_greedy_trace
from oracle import decision

FORKS={'local':12,'regime':28,'structural':40,'adversarial':22}

def make_clean(scenario):
    clean = scenario
    import copy
    clean = copy.deepcopy(scenario)
    clean.perturbations = []
    return clean

def advance(world, trace, fork):
    world.reset()
    for _ in range(fork):
        result=world.step(trace[world.ground_truth().step])
        if result.done: break

def one(seed, profile, valid_eps=0.25, obsolete_eps=1.5):
    cfg=WorldConfig(width=9,height=9,horizon=60,n_resources=7,n_opponents=1,stochasticity=0.0)
    factory=ScenarioFactory(cfg)
    pert=factory.make(seed,profile)
    clean=make_clean(pert)
    wp,wc=ResearchWorld(pert),ResearchWorld(clean)
    tp=build_greedy_trace(pert); tc=build_greedy_trace(clean)
    fork=FORKS[profile]
    advance(wp,tp,fork); advance(wc,tc,fork)
    ap=tp[fork]; ac=tc[fork]
    dp=decision(wp,ap,valid_eps,obsolete_eps)
    dc=decision(wc,ac,valid_eps,obsolete_eps)
    return {
        'seed':seed,'profile':profile,'fork':fork,
        'perturbed_gap':dp.optimality_gap,'clean_gap':dc.optimality_gap,
        'delta_gap':dp.optimality_gap-dc.optimality_gap,
        'perturbed_obsolete':dp.trace_obsolete,
        'clean_obsolete':dc.trace_obsolete,
        'perturbed_reason':dp.reason,
        'clean_reason':dc.reason,
        'trace_action':str(ap),'oracle_action_perturbed':str(dp.oracle_action),
        'oracle_action_clean':str(dc.oracle_action),
    }

def main():
    rows=[]
    for profile in FORKS:
        for seed in range(100): rows.append(one(seed,profile))
    summary={}
    for profile in FORKS:
        rs=[r for r in rows if r['profile']==profile]
        d=[r['delta_gap'] for r in rs]
        m=statistics.mean(d); ci=1.96*statistics.stdev(d)/math.sqrt(len(d))
        summary[profile]={
            'n':len(d),'mean_delta_gap':m,'ci95_delta_gap':ci,
            'obsolete_rate_perturbed':statistics.mean(r['perturbed_obsolete'] for r in rs),
            'obsolete_rate_clean':statistics.mean(r['clean_obsolete'] for r in rs),
            'causal_obsolete_switch_rate':statistics.mean((r['perturbed_obsolete'] and not r['clean_obsolete']) for r in rs),
            'rows':rs,
        }
    out=ROOT/'results/oracle_causal_profiles.json'; out.write_text(json.dumps(summary,indent=2),encoding='utf-8')
    compact={k:{kk:v for kk,v in val.items() if kk!='rows'} for k,val in summary.items()}
    print(json.dumps(compact,indent=2))

if __name__=='__main__': main()
