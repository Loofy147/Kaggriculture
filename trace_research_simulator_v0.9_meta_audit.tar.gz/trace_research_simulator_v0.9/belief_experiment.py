from __future__ import annotations
import json, math, statistics, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from simulator import ScenarioFactory, WorldConfig
from belief import MultiChannelBelief
from bocpd import GaussianBOCPD, GaussianBOCPDConfig

PROFILES=['local','regime','structural','adversarial']
SEEDS=range(20)

def stream_stats(profile, signal):
    cfg=WorldConfig(horizon=70)
    fac=ScenarioFactory(cfg)
    out=[]
    for seed in SEEDS:
        sc=fac.make(seed, profile=profile)
        world=__import__('simulator').ResearchWorld(sc)
        obs=world.reset(); b=MultiChannelBelief()
        det=GaussianBOCPD(GaussianBOCPDConfig(hazard_lambda=35.0,max_run_length=120))
        peak_after=[]; cps=[]
        oracle_change=sc.perturbations[0].start if sc.perturbations else None
        for t in range(cfg.horizon):
            # Use a neutral wait action to expose environmental sensing without agent policy confounds.
            result=world.step(__import__('simulator').Action(__import__('simulator').ActionType.WAIT))
            state=b.update(result.observation,result.feedback)
            channels=b.fused_features()
            x=float(channels.get(signal,0.0))
            s=det.update(x)
            if oracle_change is not None and t >= oracle_change:
                peak_after.append(s.cp_probability)
            obs=result.observation
            if result.done: break
        peak=max(peak_after) if peak_after else 0.0
        first=next((oracle_change+i for i,p in enumerate(peak_after) if p>0.5), None) if oracle_change is not None else None
        false=sum(1 for s in det.history[:oracle_change] if s.cp_probability>0.5) if oracle_change is not None else 0
        out.append({'peak':peak,'delay':(first-oracle_change if first is not None else None),'false':false})
    valid=[r['delay'] for r in out if r['delay'] is not None]
    return {
        'profile':profile,'signal':signal,'n':len(out),
        'detection_rate':sum(r['delay'] is not None for r in out)/len(out),
        'mean_delay':statistics.mean(valid) if valid else None,
        'false_alarm_rate':statistics.mean(r['false']>0 for r in out),
        'mean_peak':statistics.mean(r['peak'] for r in out)
    }

signals=['reward:level','reward:delta','blocked_visible_count:level','visible_resource_value:delta',
         'opponent_vulnerability:level','visible_opponent_count:delta']
rows=[]
for p in PROFILES:
    for s in signals:
        rows.append(stream_stats(p,s))

# Simple fused channel: max standardized-ish change magnitude across observation-only channels.
def fused_stream(profile):
    cfg=WorldConfig(horizon=70); fac=ScenarioFactory(cfg); rows=[]
    for seed in SEEDS:
        sc=fac.make(seed, profile=profile); world=__import__('simulator').ResearchWorld(sc); world.reset(); b=MultiChannelBelief(); det=GaussianBOCPD(GaussianBOCPDConfig(hazard_lambda=35.0,max_run_length=120))
        start=sc.perturbations[0].start if sc.perturbations else None
        post=[]; first=None; false=0
        for t in range(cfg.horizon):
            r=world.step(__import__('simulator').Action(__import__('simulator').ActionType.WAIT)); st=b.update(r.observation,r.feedback)
            # fuse robustly by sum of clipped absolute deltas, keeping signs weak.
            vals=[abs(v) for k,v in st.deltas.items() if k in {'reward','blocked_visible_count','visible_resource_value','visible_opponent_count','opponent_vulnerability','action_failed'}]
            x=min(10.0, sum(vals))
            s=det.update(x)
            if start is not None and t<start and s.cp_probability>0.5: false+=1
            if start is not None and t>=start:
                post.append(s.cp_probability)
                if first is None and s.cp_probability>0.5: first=t
            if r.done: break
        rows.append({'delay':(first-start if first is not None else None),'peak':max(post) if post else 0.0,'false':false})
    valid=[r['delay'] for r in rows if r['delay'] is not None]
    return {'profile':profile,'signal':'fused_abs_delta','n':len(rows),'detection_rate':sum(r['delay'] is not None for r in rows)/len(rows), 'mean_delay':statistics.mean(valid) if valid else None,'false_alarm_rate':statistics.mean(r['false']>0 for r in rows),'mean_peak':statistics.mean(r['peak'] for r in rows)}

for p in PROFILES: rows.append(fused_stream(p))
Path(Path(__file__).resolve().parent/'results'/'belief_bocpd_v0.7.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
print(json.dumps(rows,indent=2))
