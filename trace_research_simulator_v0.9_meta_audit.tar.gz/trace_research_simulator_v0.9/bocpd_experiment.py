from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Dict, List, Optional
import json
import statistics

from simulator import ScenarioFactory, WorldConfig, build_greedy_trace
from detector_features import scalar_observable
from bocpd import GaussianBOCPD, GaussianBOCPDConfig


@dataclass
class DetectionMetrics:
    profile: str
    seed: int
    event_start: int
    first_detection_step: Optional[int]
    detection_delay: Optional[int]
    false_alarms_before_event: int
    missed: bool
    peak_cp_probability: float


def run_episode(profile: str, seed: int, threshold: float = 0.45, hazard_lambda: float = 40.0) -> DetectionMetrics:
    cfg = WorldConfig()
    scenario = ScenarioFactory(cfg).make(seed, profile=profile)
    event_starts = [p.start for p in scenario.perturbations]
    if not event_starts:
        raise ValueError(f"No event for profile={profile}")
    event_start = min(event_starts)

    world = __import__("simulator").ResearchWorld(scenario)
    obs = world.reset()
    trace = build_greedy_trace(scenario)
    detector = GaussianBOCPD(GaussianBOCPDConfig(hazard_lambda=hazard_lambda, max_run_length=200))

    first_detection = None
    false_alarms = 0
    peak = 0.0
    for step in range(cfg.horizon):
        action = trace[min(step, len(trace)-1)]
        result = world.step(action)
        signal = scalar_observable(result.observation, result.feedback, action)
        cp = detector.update(signal).cp_probability
        peak = max(peak, cp)
        detection_step = step + 1
        if cp >= threshold:
            if detection_step < event_start:
                false_alarms += 1
            if first_detection is None and detection_step >= event_start:
                first_detection = detection_step
        if result.done:
            break

    delay = None if first_detection is None else first_detection - event_start
    return DetectionMetrics(
        profile=profile,
        seed=seed,
        event_start=event_start,
        first_detection_step=first_detection,
        detection_delay=delay,
        false_alarms_before_event=false_alarms,
        missed=first_detection is None,
        peak_cp_probability=peak,
    )


def summarize(rows: List[DetectionMetrics]) -> Dict[str, Dict[str, float]]:
    out: Dict[str, Dict[str, float]] = {}
    for profile in sorted({r.profile for r in rows}):
        rs = [r for r in rows if r.profile == profile]
        detected = [r for r in rs if r.detection_delay is not None]
        out[profile] = {
            "episodes": len(rs),
            "detection_rate": len(detected) / max(1, len(rs)),
            "mean_delay_detected": statistics.mean(r.detection_delay for r in detected) if detected else None,
            "median_delay_detected": statistics.median(r.detection_delay for r in detected) if detected else None,
            "mean_false_alarms": statistics.mean(r.false_alarms_before_event for r in rs),
            "mean_peak_cp": statistics.mean(r.peak_cp_probability for r in rs),
        }
    return out


def main() -> None:
    profiles = ["local", "regime", "structural", "adversarial"]
    rows = []
    for profile in profiles:
        for seed in range(40):
            rows.append(run_episode(profile, seed))
    payload = {"summary": summarize(rows), "rows": [asdict(r) for r in rows]}
    path = "/mnt/data/trace_research_simulator/results/bocpd_v0.6.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, allow_nan=False)
    print(json.dumps(payload["summary"], indent=2))


if __name__ == "__main__":
    main()
