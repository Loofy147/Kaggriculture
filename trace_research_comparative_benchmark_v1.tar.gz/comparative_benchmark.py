from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple
import copy
import json
import statistics

from simulator import Scenario, ResearchWorld, Action, ActionType, build_greedy_trace
from agents import (
    AgentBase,
    TraceOnlyAgent,
    ReactiveRepairAgent,
    TriggeredReplanAgent,
    ReplanAgent,
    OpportunisticAgent,
)


class BehaviorTreeBaseline(AgentBase):
    """Representative reactive BT-style selector, not a literature reimplementation.

    Priority:
        1) retry interrupted execution
        2) avoid visible blocked trace step
        3) collect immediately reachable resource
        4) execute trace
        5) wait
    """
    name = "behavior_tree"

    def __init__(self, trace: List[Action]):
        self.trace = trace

    def act(self, obs, feedback):
        if feedback and feedback.get("status") == "partial" and feedback.get("remainder"):
            rem = feedback["remainder"]
            return Action(ActionType(rem["kind"]), tuple(rem["target"]) if rem.get("target") else None)

        base = self.trace[min(obs.step, len(self.trace) - 1)]
        if obs.blocked_visible and base.kind == ActionType.MOVE and base.target in obs.blocked_visible:
            x, y = obs.agent_pos
            candidates = [(x+1,y),(x-1,y),(x,y+1),(x,y-1)]
            candidates = [q for q in candidates if q not in obs.blocked_visible and q != obs.agent_pos]
            if candidates:
                tx, ty = base.target
                target = min(candidates, key=lambda q: abs(q[0]-tx) + abs(q[1]-ty))
                return Action(ActionType.MOVE, target)
            return Action(ActionType.WAIT)

        here = [r for r in obs.visible_resources.values() if r.pos == obs.agent_pos and r.available]
        if here:
            return Action(ActionType.COLLECT, obs.agent_pos)

        return base


class PlanExecuteMonitorRepairBaseline(AgentBase):
    """Representative plan-execute-monitor-repair controller."""
    name = "plan_monitor_repair"

    def __init__(self, trace: List[Action]):
        self.trace = trace

    def act(self, obs, feedback):
        base = self.trace[min(obs.step, len(self.trace) - 1)]
        failure = bool(feedback and feedback.get("status") in {"blocked", "no_resource", "reserve_failed", "partial"})
        blocked = base.kind == ActionType.MOVE and base.target in obs.blocked_visible
        if not failure and not blocked:
            return base

        if feedback and feedback.get("status") == "partial" and feedback.get("remainder"):
            rem = feedback["remainder"]
            return Action(ActionType(rem["kind"]), tuple(rem["target"]) if rem.get("target") else None)

        if not obs.visible_resources:
            return Action(ActionType.WAIT)
        target = min(
            obs.visible_resources.values(),
            key=lambda r: abs(r.pos[0]-obs.agent_pos[0]) + abs(r.pos[1]-obs.agent_pos[1]),
        )
        if target.pos == obs.agent_pos:
            return Action(ActionType.COLLECT, target.pos)
        return Action(ActionType.MOVE, target.pos)


class SimplexRepresentative(AgentBase):
    """Representative Simplex/RTA pattern, not a formal safety-guaranteed instance.

    Advanced controller: replan.
    Reversionary controller: trace-following controller.
    Decision module: switches only on explicit monitor triggers.
    """
    name = "simplex_representative"

    def __init__(self, trace: List[Action], threshold: float = 0.6):
        self.advanced = ReplanAgent(trace)
        self.reversionary = TraceOnlyAgent(trace)
        self.threshold = threshold
        self.mode = "advanced"
        self.switch_count = 0

    def reset(self):
        self.mode = "advanced"
        self.switch_count = 0
        self.advanced.reset()
        self.reversionary.reset()

    def act(self, obs, feedback):
        unsafe = bool(
            obs.regime_signal >= self.threshold
            or obs.blocked_visible
            or (feedback and feedback.get("status") in {"blocked", "no_resource", "reserve_failed"})
        )
        new_mode = "reversionary" if unsafe else "advanced"
        if new_mode != self.mode:
            self.switch_count += 1
            self.mode = new_mode
        if self.mode == "reversionary":
            return self.reversionary.act(obs, feedback)
        return self.advanced.act(obs, feedback)


class OptionSwitchBaseline(AgentBase):
    """Representative policy-over-options baseline.

    Option 1: follow the reference trace.
    Option 2: navigate toward nearest visible resource.
    Selection is a simple state-dependent initiation rule.
    """
    name = "option_switch"

    def __init__(self, trace: List[Action]):
        self.trace = trace
        self.option = "trace"
        self.switch_count = 0

    def reset(self):
        self.option = "trace"
        self.switch_count = 0

    def act(self, obs, feedback):
        old = self.option
        urgent = bool(obs.blocked_visible or obs.regime_signal >= 0.6)
        self.option = "resource" if urgent and obs.visible_resources else "trace"
        if self.option != old:
            self.switch_count += 1

        if feedback and feedback.get("status") == "partial" and feedback.get("remainder"):
            rem = feedback["remainder"]
            return Action(ActionType(rem["kind"]), tuple(rem["target"]) if rem.get("target") else None)

        if self.option == "trace":
            return self.trace[min(obs.step, len(self.trace) - 1)]
        target = min(obs.visible_resources.values(), key=lambda r: abs(r.pos[0]-obs.agent_pos[0]) + abs(r.pos[1]-obs.agent_pos[1]))
        if target.pos == obs.agent_pos:
            return Action(ActionType.COLLECT, target.pos)
        return Action(ActionType.MOVE, target.pos)


class ValidityAwarePrototype(AgentBase):
    """Prototype of our proposed validity-aware intervention principle.

    This is deliberately conservative and uses only online-visible proxies:
    blocked trace, regime signal, visible objective availability, and recent
    execution failures. It is NOT allowed to read oracle validity.
    """
    name = "validity_aware_prototype"

    def __init__(self, trace: List[Action], enter_threshold: int = 2, exit_threshold: int = 1):
        self.trace = trace
        self.enter_threshold = enter_threshold
        self.exit_threshold = exit_threshold
        self.risk_score = 0
        self.mode = "trace"
        self.switch_count = 0

    def reset(self):
        self.risk_score = 0
        self.mode = "trace"
        self.switch_count = 0

    def act(self, obs, feedback):
        evidence = 0
        base = self.trace[min(obs.step, len(self.trace)-1)]
        if base.kind == ActionType.MOVE and base.target in obs.blocked_visible:
            evidence += 2
        if obs.regime_signal >= 0.6:
            evidence += 1
        if feedback and feedback.get("status") in {"blocked", "no_resource", "reserve_failed"}:
            evidence += 2
        if not obs.visible_resources:
            evidence += 1

        self.risk_score = max(0, self.risk_score + evidence - 1)
        old = self.mode
        if self.risk_score >= self.enter_threshold:
            self.mode = "replan"
        elif self.risk_score <= self.exit_threshold - 1:
            self.mode = "trace"
        if self.mode != old:
            self.switch_count += 1

        if feedback and feedback.get("status") == "partial" and feedback.get("remainder"):
            rem = feedback["remainder"]
            return Action(ActionType(rem["kind"]), tuple(rem["target"]) if rem.get("target") else None)

        if self.mode == "trace":
            return base

        if not obs.visible_resources:
            return Action(ActionType.WAIT)
        target = min(obs.visible_resources.values(), key=lambda r: abs(r.pos[0]-obs.agent_pos[0]) + abs(r.pos[1]-obs.agent_pos[1]))
        if target.pos == obs.agent_pos:
            return Action(ActionType.COLLECT, target.pos)
        return Action(ActionType.MOVE, target.pos)


BASELINES: Dict[str, Callable[[List[Action]], AgentBase]] = {
    "trace_only": TraceOnlyAgent,
    "trace_reactive": ReactiveRepairAgent,
    "behavior_tree": BehaviorTreeBaseline,
    "plan_monitor_repair": PlanExecuteMonitorRepairBaseline,
    "simplex_representative": SimplexRepresentative,
    "option_switch": OptionSwitchBaseline,
    "validity_aware_prototype": ValidityAwarePrototype,
}


@dataclass
class BenchmarkRow:
    scenario_id: str
    profile: str
    agent: str
    reward: float
    success: bool
    goals_collected: int
    goals_lost: int
    catastrophic_failures: int
    blocked_actions: int
    partial_actions: int
    interventions: int
    switches: int
    trace_match: float
    recovery_debt: float
    max_deviation: float


def _dist(a, b):
    return abs(a[0]-b[0]) + abs(a[1]-b[1])


def run_episode(scenario: Scenario, factory: Callable[[List[Action]], AgentBase]) -> BenchmarkRow:
    world = ResearchWorld(scenario)
    trace = build_greedy_trace(scenario)
    agent = factory(trace)
    agent.reset()
    obs = world.reset()
    feedback = None
    matched = 0
    interventions = 0
    blocked = partial = catastrophe = 0
    recovery_debt = 0.0
    deviations: List[float] = []

    for _ in range(scenario.config.horizon):
        expected = trace[obs.step] if obs.step < len(trace) else Action(ActionType.WAIT)
        action = agent.act(obs, feedback)
        matched += int(action == expected)
        interventions += int(action != expected)
        truth_before = world.ground_truth()
        result = world.step(action)
        ref_pos = truth_before.agent.pos
        if expected.kind == ActionType.MOVE and expected.target is not None:
            ref_pos = world._step_toward(ref_pos, expected.target)
        deviations.append(float(_dist(result.truth.agent.pos, ref_pos)))
        feedback = result.feedback
        if feedback["status"] == "blocked":
            blocked += 1
            recovery_debt += 1.0
        if feedback["partial"]:
            partial += 1
            recovery_debt += 0.5
        if feedback["status"] == "no_resource":
            catastrophe += 1
        if feedback["executed"] and feedback["reward"] > 0:
            recovery_debt = max(0.0, recovery_debt - 0.1)
        obs = result.observation
        if result.done:
            break

    truth = world.ground_truth()
    return BenchmarkRow(
        scenario_id=scenario.scenario_id,
        profile=next((p for p in ["local","regime","structural","adversarial","mixed","all"] if f"profile={p}" in scenario.scenario_id), "unknown"),
        agent=getattr(agent, "name", factory.__name__),
        reward=truth.total_reward,
        success=(len(truth.collected_goals) == len(truth.initial_goals)),
        goals_collected=len(truth.collected_goals),
        goals_lost=len(truth.lost_goals),
        catastrophic_failures=catastrophe,
        blocked_actions=blocked,
        partial_actions=partial,
        interventions=interventions,
        switches=int(getattr(agent, "switch_count", 0)),
        trace_match=matched / max(1, truth.step),
        recovery_debt=recovery_debt,
        max_deviation=max(deviations) if deviations else 0.0,
    )


def run_benchmark(scenarios: Sequence[Scenario], factories=BASELINES) -> List[BenchmarkRow]:
    rows: List[BenchmarkRow] = []
    for scenario in scenarios:
        for name, factory in factories.items():
            row = run_episode(scenario, factory)
            row.agent = name
            rows.append(row)
    return rows


def aggregate(rows: Sequence[BenchmarkRow]) -> Dict[str, Dict[str, float]]:
    by: Dict[str, List[BenchmarkRow]] = {}
    for r in rows:
        by.setdefault(r.agent, []).append(r)
    out: Dict[str, Dict[str, float]] = {}
    fields = ["reward","goals_collected","goals_lost","catastrophic_failures","blocked_actions","partial_actions","interventions","switches","trace_match","recovery_debt","max_deviation"]
    for agent, rr in by.items():
        out[agent] = {f: statistics.mean(getattr(r, f) for r in rr) for f in fields}
        out[agent]["success_rate"] = statistics.mean(float(r.success) for r in rr)
    return out


def profile_aggregate(rows: Sequence[BenchmarkRow]) -> Dict[str, Dict[str, Dict[str, float]]]:
    out: Dict[str, Dict[str, List[BenchmarkRow]]] = {}
    for r in rows:
        out.setdefault(r.profile, {}).setdefault(r.agent, []).append(r)
    result: Dict[str, Dict[str, Dict[str, float]]] = {}
    for profile, agents in out.items():
        result[profile] = {}
        for agent, rr in agents.items():
            result[profile][agent] = {
                "reward": statistics.mean(r.reward for r in rr),
                "success_rate": statistics.mean(float(r.success) for r in rr),
                "goals_collected": statistics.mean(r.goals_collected for r in rr),
                "goals_lost": statistics.mean(r.goals_lost for r in rr),
                "catastrophic_failures": statistics.mean(r.catastrophic_failures for r in rr),
                "interventions": statistics.mean(r.interventions for r in rr),
                "switches": statistics.mean(r.switches for r in rr),
                "recovery_debt": statistics.mean(r.recovery_debt for r in rr),
            }
    return result


def main():
    from simulator import ScenarioFactory, WorldConfig
    cfg = WorldConfig(horizon=60)
    factory = ScenarioFactory(cfg)
    scenarios = [factory.make(seed=s, profile=p) for s in range(20) for p in ("local","regime","structural","adversarial","mixed")]
    rows = run_benchmark(scenarios)
    payload = {
        "protocol": {
            "seed_range": [0, 19],
            "profiles": ["local","regime","structural","adversarial","mixed"],
            "agents": list(BASELINES),
            "same_scenarios": True,
            "oracle_access": False,
            "note": "Architectures are representative baseline implementations, not faithful reimplementations of cited papers."
        },
        "aggregate": aggregate(rows),
        "profile_aggregate": profile_aggregate(rows),
        "rows": [asdict(r) for r in rows],
    }
    out = "/mnt/data/trace_research_simulator_v0.9/results/comparative_benchmark_v1.json"
    with open(out, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    print(json.dumps(payload["aggregate"], indent=2))


if __name__ == "__main__":
    main()
