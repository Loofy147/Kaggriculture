from simulator import ScenarioFactory, WorldConfig
from comparative_benchmark import BASELINES, run_benchmark, aggregate, profile_aggregate


def test_all_baselines_build_and_run():
    cfg = WorldConfig(horizon=15)
    sf = ScenarioFactory(cfg)
    scenarios = [sf.make(seed=1, profile=p) for p in ("local", "regime", "structural", "adversarial", "mixed")]
    rows = run_benchmark(scenarios)
    assert len(rows) == len(scenarios) * len(BASELINES)
    assert set(r.agent for r in rows) == set(BASELINES)
    assert all(r.reward == r.reward for r in rows)  # no NaN


def test_same_scenarios_for_all_agents():
    cfg = WorldConfig(horizon=10)
    sf = ScenarioFactory(cfg)
    scenarios = [sf.make(seed=s, profile="local") for s in range(3)]
    rows = run_benchmark(scenarios)
    ids = {name: {r.scenario_id for r in rows if r.agent == name} for name in BASELINES}
    assert len({tuple(sorted(v)) for v in ids.values()}) == 1


def test_no_oracle_fields_in_observation_path():
    cfg = WorldConfig(horizon=5)
    sf = ScenarioFactory(cfg)
    scenario = sf.make(seed=2, profile="mixed")
    # This test is intentionally structural: observation must not expose validity/oracle labels.
    obs_keys = set(scenario.config.__dataclass_fields__.keys())
    forbidden = {"trace_valid", "trace_obsolete", "optimality_gap", "oracle_action"}
    assert not (obs_keys & forbidden)
