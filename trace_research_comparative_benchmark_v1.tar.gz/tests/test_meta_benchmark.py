from comparative_benchmark import BASELINES
from meta_benchmark import (
    make_in_distribution_scenarios,
    paired_scenario_check,
    profile_balance_check,
    oracle_leakage_schema_check,
)
from comparative_benchmark import run_benchmark


def test_meta_protocol_checks():
    scenarios = make_in_distribution_scenarios(2)
    rows = run_benchmark(scenarios)
    assert paired_scenario_check(rows, BASELINES.keys())["pass"]
    assert profile_balance_check(rows, ("local","regime","structural","adversarial","mixed"), min_n=2)["pass"]
    assert oracle_leakage_schema_check()["pass"]
