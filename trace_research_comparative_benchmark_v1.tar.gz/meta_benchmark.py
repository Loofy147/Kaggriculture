from __future__ import annotations

from dataclasses import asdict
from typing import Dict, List, Sequence, Any
import hashlib
import json
import math
import statistics

from simulator import ScenarioFactory, WorldConfig, Scenario
from comparative_benchmark import BASELINES, BenchmarkRow, run_benchmark, aggregate, profile_aggregate


FORBIDDEN_ORACLE_FIELDS = {
    "trace_valid", "trace_obsolete", "optimality_gap", "oracle_action",
    "oracle_score", "trace_score", "repairable", "first_obsolete_step",
}


def _canonical_rows(rows: Sequence[BenchmarkRow]) -> str:
    payload = [asdict(r) for r in rows]
    return json.dumps(payload, sort_keys=True, separators=(",", ":"))


def _hash_rows(rows: Sequence[BenchmarkRow]) -> str:
    return hashlib.sha256(_canonical_rows(rows).encode()).hexdigest()


def paired_scenario_check(rows: Sequence[BenchmarkRow], expected_agents: Sequence[str]) -> Dict[str, Any]:
    expected_agents = set(expected_agents)
    by_scenario: Dict[str, set[str]] = {}
    for r in rows:
        by_scenario.setdefault(r.scenario_id, set()).add(r.agent)
    bad = {sid: sorted(agents) for sid, agents in by_scenario.items() if agents != expected_agents}
    return {
        "pass": not bad,
        "scenario_count": len(by_scenario),
        "bad_scenarios": bad,
    }


def profile_balance_check(rows: Sequence[BenchmarkRow], expected_profiles: Sequence[str], min_n: int = 1) -> Dict[str, Any]:
    counts: Dict[str, int] = {p: 0 for p in expected_profiles}
    for r in rows:
        counts[r.profile] = counts.get(r.profile, 0) + 1
    return {
        "pass": all(counts.get(p, 0) >= min_n for p in expected_profiles),
        "counts": counts,
    }


def oracle_leakage_schema_check() -> Dict[str, Any]:
    # Observation is deliberately imported only as a runtime schema here.
    from simulator import Observation
    fields = set(Observation.__dataclass_fields__.keys())
    leakage = sorted(fields & FORBIDDEN_ORACLE_FIELDS)
    return {
        "pass": not leakage,
        "observation_fields": sorted(fields),
        "forbidden_present": leakage,
    }


def deterministic_replay_check(scenarios: Sequence[Scenario]) -> Dict[str, Any]:
    rows1 = run_benchmark(scenarios)
    rows2 = run_benchmark(scenarios)
    h1 = _hash_rows(rows1)
    h2 = _hash_rows(rows2)
    return {
        "pass": h1 == h2,
        "hash_1": h1,
        "hash_2": h2,
    }


def metric_health(rows: Sequence[BenchmarkRow]) -> Dict[str, Any]:
    success_values = [float(r.success) for r in rows]
    completion = [r.goals_collected / max(1, r.goals_collected + r.goals_lost + (0 if r.goals_collected else 1)) for r in rows]
    success_mean = statistics.mean(success_values) if success_values else 0.0
    success_var = statistics.pvariance(success_values) if len(success_values) > 1 else 0.0
    completion_var = statistics.pvariance(completion) if len(completion) > 1 else 0.0
    return {
        "exact_success_rate": success_mean,
        "exact_success_variance": success_var,
        "exact_success_saturated": success_var == 0.0,
        "completion_rate_mean": statistics.mean(completion) if completion else 0.0,
        "completion_rate_variance": completion_var,
        "completion_has_discrimination": completion_var > 0.0,
    }


def _pareto_frontier(summary: Dict[str, Dict[str, float]]) -> List[str]:
    # Maximize reward and success; minimize catastrophic failures and interventions.
    agents = list(summary)
    frontier = []
    for a in agents:
        sa = summary[a]
        dominated = False
        for b in agents:
            if a == b:
                continue
            sb = summary[b]
            not_worse = (
                sb["reward"] >= sa["reward"]
                and sb["success_rate"] >= sa["success_rate"]
                and sb["catastrophic_failures"] <= sa["catastrophic_failures"]
                and sb["interventions"] <= sa["interventions"]
            )
            strictly = (
                sb["reward"] > sa["reward"]
                or sb["success_rate"] > sa["success_rate"]
                or sb["catastrophic_failures"] < sa["catastrophic_failures"]
                or sb["interventions"] < sa["interventions"]
            )
            if not_worse and strictly:
                dominated = True
                break
        if not dominated:
            frontier.append(a)
    return frontier


def make_in_distribution_scenarios(n_seeds: int = 40) -> List[Scenario]:
    cfg = WorldConfig(horizon=60)
    factory = ScenarioFactory(cfg)
    return [factory.make(seed=s, profile=p) for s in range(n_seeds) for p in ("local", "regime", "structural", "adversarial", "mixed")]


def make_ood_scenarios(n_seeds: int = 20) -> List[Scenario]:
    # Unseen generator/configuration family: different geometry, observation radius,
    # stochasticity, opponent strength and regime multiplier.
    cfg = WorldConfig(
        width=11,
        height=11,
        horizon=70,
        n_resources=8,
        n_opponents=2,
        opponent_strength=0.85,
        stochasticity=0.10,
        observation_radius=4,
        regime_move_cost_multiplier=3.5,
        regime_opponent_bonus=0.35,
    )
    factory = ScenarioFactory(cfg)
    return [factory.make(seed=10_000 + s, profile=p) for s in range(n_seeds) for p in ("local", "regime", "structural", "adversarial", "mixed")]


def run_meta_benchmark(in_n: int = 40, ood_n: int = 20) -> Dict[str, Any]:
    in_scenarios = make_in_distribution_scenarios(in_n)
    ood_scenarios = make_ood_scenarios(ood_n)

    in_rows = run_benchmark(in_scenarios)
    ood_rows = run_benchmark(ood_scenarios)

    checks = {
        "in_distribution_pairs": paired_scenario_check(in_rows, BASELINES.keys()),
        "ood_pairs": paired_scenario_check(ood_rows, BASELINES.keys()),
        "in_profiles": profile_balance_check(in_rows, ("local","regime","structural","adversarial","mixed"), min_n=in_n),
        "ood_profiles": profile_balance_check(ood_rows, ("local","regime","structural","adversarial","mixed"), min_n=ood_n),
        "oracle_leakage_schema": oracle_leakage_schema_check(),
        "deterministic_replay": deterministic_replay_check(in_scenarios[:25]),
    }

    in_agg = aggregate(in_rows)
    ood_agg = aggregate(ood_rows)

    # Sign-safe generalization descriptors. Ratios are invalid when the baseline reward
    # crosses zero, so use absolute delta and symmetric normalized change only when valid.
    generalization = {}
    for agent in BASELINES:
        in_reward = in_agg[agent]["reward"]
        ood_reward = ood_agg[agent]["reward"]
        in_success = in_agg[agent]["success_rate"]
        ood_success = ood_agg[agent]["success_rate"]
        denom = abs(in_reward) + abs(ood_reward)
        generalization[agent] = {
            "reward_delta_ood_minus_in": ood_reward - in_reward,
            "reward_symmetric_change": (ood_reward - in_reward) / denom if denom else 0.0,
            "reward_sign_changed": (in_reward < 0 < ood_reward) or (ood_reward < 0 < in_reward),
            "success_delta": ood_success - in_success,
        }

    result = {
        "protocol": {
            "baseline_note": "Representative implementations of architecture families; not claim-equivalent reimplementations of cited papers.",
            "in_distribution": {
                "seeds": in_n,
                "profiles": ["local","regime","structural","adversarial","mixed"],
                "same_world_per_agent": True,
            },
            "ood": {
                "seeds": ood_n,
                "unseen_config": True,
                "profiles": ["local","regime","structural","adversarial","mixed"],
            },
        },
        "checks": checks,
        "in_distribution": {
            "aggregate": in_agg,
            "profile_aggregate": profile_aggregate(in_rows),
            "metric_health": metric_health(in_rows),
            "pareto_frontier": _pareto_frontier(in_agg),
        },
        "ood": {
            "aggregate": ood_agg,
            "profile_aggregate": profile_aggregate(ood_rows),
            "metric_health": metric_health(ood_rows),
            "pareto_frontier": _pareto_frontier(ood_agg),
        },
        "generalization": generalization,
    }

    out = "/mnt/data/trace_research_simulator_v0.9/results/comparative_meta_benchmark_v1.json"
    with open(out, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    return result


if __name__ == "__main__":
    result = run_meta_benchmark()
    print(json.dumps(result, indent=2))
