from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Dict, List, Callable, Sequence, Any, Optional, Tuple
import json, math, statistics, copy

from simulator import (
    ScenarioFactory, WorldConfig, Scenario, ResearchWorld,
    Action, ActionType, Observation, build_greedy_trace
)
from agents import AgentBase, TraceOnlyAgent, ReactiveRepairAgent, ChangeAwareAgent, TriggeredReplanAgent, ReplanAgent
from comparative_benchmark import (BehaviorTreeBaseline, PlanExecuteMonitorRepairBaseline, SimplexRepresentative, OptionSwitchBaseline)

# -----------------------------------------------------------------------------
# Benchmark design
# -----------------------------------------------------------------------------
# This benchmark is intentionally separate from v1. It does not overwrite the
# prior results. It treats objective completion as a continuous quantity and
# adds explicit intervention cost. The proposed policy is a representative
# implementation of the hypothesis, not a claim of equivalence to prior work.

BASELINES: Dict[str, Callable[[List[Action]], AgentBase]] = {
    "trace_only": TraceOnlyAgent,
    "trace_reactive": ReactiveRepairAgent,
    "behavior_tree": BehaviorTreeBaseline,
    "plan_monitor_repair": PlanExecuteMonitorRepairBaseline,
    "simplex_representative": SimplexRepresentative,
    "option_switch": OptionSwitchBaseline,
    "validity_aware_prototype": ChangeAwareAgent,
    "triggered_replan": TriggeredReplanAgent,
    "replan": ReplanAgent,
}

POS_COST = {
    "MOVE": 0.05,
    "COLLECT": 0.10,
    "RESERVE": 0.08,
    "WAIT": 0.03,
}


def dist(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def action_to_resource_target(action: Action, obs: Observation):
    if action.kind in (ActionType.MOVE, ActionType.COLLECT, ActionType.RESERVE):
        if action.target is not None:
            return action.target
    return None


def nearest_visible(obs: Observation):
    if not obs.visible_resources:
        return None
    return min(obs.visible_resources.values(), key=lambda r: dist(r.pos, obs.agent_pos))


class MinimalInterventionAgent(TraceOnlyAgent):
    """Representative minimal-intervention controller.

    Decision ladder:
      1. Keep the trace if it is immediately feasible and not contradicted.
      2. Apply the smallest local repair when the trace is blocked.
      3. Switch to a nearby visible resource only on stronger evidence that the
         reference action cannot make progress.
      4. Fall back to WAIT if no lower-cost intervention is supported.

    The controller does NOT have oracle access, and it does not estimate global
    optimality. This is deliberately a conservative heuristic baseline for the
    hypothesis under test.
    """
    name = "minimal_intervention"

    def __init__(self, trace: List[Action]):
        super().__init__(trace)
        self.intervention_cost = 0.0
        self.repair_count = 0
        self.switch_count = 0

    def reset(self):
        self.intervention_cost = 0.0
        self.repair_count = 0
        self.switch_count = 0

    def _record(self, base: Action, chosen: Action, kind: str):
        if chosen != base:
            self.intervention_cost += POS_COST.get(chosen.kind.value, 0.05)
            if kind == "repair":
                self.repair_count += 1
            elif kind == "switch":
                self.switch_count += 1

    def _repair_action(self, obs: Observation, base: Action) -> Optional[Action]:
        if base.kind != ActionType.MOVE or base.target is None:
            return None
        if base.target not in obs.blocked_visible:
            return None
        x, y = obs.agent_pos
        tx, ty = base.target
        candidates = []
        for q in ((x+1,y),(x-1,y),(x,y+1),(x,y-1)):
            if q == obs.agent_pos or q in obs.blocked_visible:
                continue
            candidates.append(q)
        if not candidates:
            return None
        detour = min(candidates, key=lambda q: dist(q, (tx, ty)))
        return Action(ActionType.MOVE, detour)

    def act(self, obs: Observation, feedback: Optional[dict]) -> Action:
        base = super().act(obs, feedback)

        # Execution repair has the smallest intervention distance.
        if feedback and feedback.get("status") == "partial" and feedback.get("remainder"):
            rem = feedback["remainder"]
            chosen = Action(ActionType(rem["kind"]), tuple(rem["target"]) if rem.get("target") else None)
            self._record(base, chosen, "repair")
            return chosen

        repair = self._repair_action(obs, base)
        if repair is not None:
            self._record(base, repair, "repair")
            return repair

        # Do not switch merely because the world is noisy. Require evidence that
        # the reference action is presently unlikely to make progress.
        hard_failure = feedback and feedback.get("status") in {
            "no_resource", "reserve_failed"
        }
        high_regime = obs.regime_signal >= 0.8
        if hard_failure or high_regime:
            target = nearest_visible(obs)
            if target is not None:
                if target.pos == obs.agent_pos:
                    chosen = Action(ActionType.COLLECT, target.pos)
                else:
                    chosen = Action(ActionType.MOVE, target.pos)
                self._record(base, chosen, "switch")
                return chosen

        self._record(base, base, "none")
        return base


class AggressiveReplanAgent(ReplanAgent):
    name = "aggressive_replan"


BASELINES["minimal_intervention"] = MinimalInterventionAgent


@dataclass
class Metrics:
    scenario_id: str
    profile: str
    agent: str
    reward: float
    goals_total: int
    goals_collected: int
    goals_lost: int
    progress_score: float
    objective_completion: float
    catastrophe_rate: float
    blocked_actions: int
    intervention_steps: int
    intervention_rate: float
    intervention_cost: float
    trace_match_rate: float
    recovery_debt: float
    mean_trace_deviation: float
    switches: int
    repairs: int


def objective_completion(truth) -> float:
    total = max(1, len(truth.initial_goals))
    return len(truth.collected_goals) / total


def progress_score(truth) -> float:
    total = max(1, len(truth.initial_goals))
    # Continuous and signed: losses count against progress, without saturating
    # at a single Boolean success value.
    return (len(truth.collected_goals) - 0.75 * len(truth.lost_goals)) / total


def run_episode(scenario: Scenario, factory):
    world = ResearchWorld(scenario)
    trace = build_greedy_trace(scenario)
    agent = factory(trace)
    agent.reset()
    obs = world.reset()
    feedback = None
    matched = 0
    interventions = 0
    blocked = 0
    catastrophe = 0
    recovery_debt = 0.0
    deviations = []
    repairs = 0
    switches = 0
    common_intervention_cost = 0.0
    for _ in range(scenario.config.horizon):
        expected = trace[obs.step] if obs.step < len(trace) else Action(ActionType.WAIT)
        action = agent.act(obs, feedback)
        if action == expected:
            matched += 1
        else:
            interventions += 1
            common_intervention_cost += POS_COST.get(action.kind.value, 0.05)
        before = world.ground_truth()
        result = world.step(action)
        ref_pos = before.agent.pos
        if expected.kind == ActionType.MOVE and expected.target is not None:
            ref_pos = world._step_toward(ref_pos, expected.target)
        deviations.append(dist(result.truth.agent.pos, ref_pos))
        feedback = result.feedback
        if feedback["status"] == "blocked":
            blocked += 1
            recovery_debt += 1.0
        if feedback["status"] == "no_resource":
            catastrophe += 1
            recovery_debt += 1.0
        if feedback["partial"]:
            recovery_debt += 0.5
        if feedback["executed"] and feedback["reward"] > 0:
            recovery_debt = max(0.0, recovery_debt - 0.1)
        obs = result.observation
        if result.done:
            break
    truth = world.ground_truth()
    if hasattr(agent, "repair_count"):
        repairs = agent.repair_count
    if hasattr(agent, "switch_count"):
        switches = agent.switch_count
    agent._common_intervention_cost = common_intervention_cost
    # Fair metric: every architecture pays the same explicit cost for
    # deviating from the reference action. Controller-specific accounting
    # remains useful for diagnostics, but ranking uses this common metric.
    intervention_cost = common_intervention_cost
    steps = max(1, truth.step)
    return Metrics(
        scenario_id=scenario.scenario_id,
        profile=next((p for p in ["local","regime","structural","adversarial","mixed"] if f"profile={p}" in scenario.scenario_id), "unknown"),
        agent=getattr(agent, "name", factory.__name__),
        reward=truth.total_reward,
        goals_total=len(truth.initial_goals),
        goals_collected=len(truth.collected_goals),
        goals_lost=len(truth.lost_goals),
        progress_score=progress_score(truth),
        objective_completion=objective_completion(truth),
        catastrophe_rate=catastrophe / steps,
        blocked_actions=blocked,
        intervention_steps=interventions,
        intervention_rate=interventions / steps,
        intervention_cost=intervention_cost,
        trace_match_rate=matched / steps,
        recovery_debt=recovery_debt,
        mean_trace_deviation=statistics.mean(deviations) if deviations else 0.0,
        switches=switches,
        repairs=repairs,
    )


def aggregate(rows: Sequence[Metrics]):
    groups: Dict[str, List[Metrics]] = {}
    for r in rows:
        groups.setdefault(r.agent, []).append(r)
    out = {}
    fields = [
        "reward", "progress_score", "objective_completion", "catastrophe_rate",
        "blocked_actions", "intervention_steps", "intervention_rate",
        "intervention_cost", "trace_match_rate", "recovery_debt",
        "mean_trace_deviation", "switches", "repairs",
    ]
    for agent, rs in groups.items():
        out[agent] = {f: statistics.mean(getattr(r,f) for r in rs) for f in fields}
        out[agent]["n"] = len(rs)
    return out


def metric_health(rows):
    completion = [r.objective_completion for r in rows]
    progress = [r.progress_score for r in rows]
    return {
        "objective_completion_variance": statistics.pvariance(completion) if len(completion)>1 else 0.0,
        "progress_score_variance": statistics.pvariance(progress) if len(progress)>1 else 0.0,
        "objective_completion_discriminative": (statistics.pvariance(completion) if len(completion)>1 else 0.0) > 1e-8,
        "progress_score_discriminative": (statistics.pvariance(progress) if len(progress)>1 else 0.0) > 1e-8,
    }


def pareto(summary: Dict[str, Dict[str,float]]):
    # Maximize reward/progress/completion; minimize intervention, catastrophe, debt.
    agents = list(summary)
    front=[]
    for a in agents:
        sa=summary[a]
        dominated=False
        for b in agents:
            if a==b: continue
            sb=summary[b]
            nw=(sb["reward"]>=sa["reward"] and sb["progress_score"]>=sa["progress_score"] and
                sb["objective_completion"]>=sa["objective_completion"] and
                sb["catastrophe_rate"]<=sa["catastrophe_rate"] and
                sb["intervention_cost"]<=sa["intervention_cost"])
            strict=(sb["reward"]>sa["reward"] or sb["progress_score"]>sa["progress_score"] or
                    sb["objective_completion"]>sa["objective_completion"] or
                    sb["catastrophe_rate"]<sa["catastrophe_rate"] or
                    sb["intervention_cost"]<sa["intervention_cost"])
            if nw and strict:
                dominated=True; break
        if not dominated:
            front.append(a)
    return front


def make_scenarios(n:int, ood:bool=False):
    if not ood:
        cfg=WorldConfig(horizon=60)
        fac=ScenarioFactory(cfg)
        seeds=range(n)
    else:
        cfg=WorldConfig(width=12,height=12,horizon=70,n_resources=8,n_opponents=2,opponent_strength=0.88,
                        stochasticity=0.12,observation_radius=3,regime_move_cost_multiplier=3.8,regime_opponent_bonus=0.4)
        fac=ScenarioFactory(cfg)
        seeds=range(10000,10000+n)
    return [fac.make(seed=s, profile=p) for s in seeds for p in ("local","regime","structural","adversarial","mixed")]


def paired_delta(rows_a, rows_b, metric):
    a={r.scenario_id:r for r in rows_a}; b={r.scenario_id:r for r in rows_b}
    common=sorted(set(a)&set(b))
    vals=[getattr(b[s],metric)-getattr(a[s],metric) for s in common]
    if not vals: return {"n":0}
    mean=statistics.mean(vals)
    sd=statistics.stdev(vals) if len(vals)>1 else 0.0
    se=sd/math.sqrt(len(vals)) if vals else 0.0
    return {"n":len(vals),"mean":mean,"sd":sd,"ci95_low":mean-1.96*se,"ci95_high":mean+1.96*se}


def run(n_id=30,n_ood=15):
    id_s=make_scenarios(n_id,False); ood_s=make_scenarios(n_ood,True)
    id_rows=[]; ood_rows=[]
    for s in id_s:
        for fac in BASELINES.values(): id_rows.append(run_episode(s,fac))
    for s in ood_s:
        for fac in BASELINES.values(): ood_rows.append(run_episode(s,fac))
    id_agg=aggregate(id_rows); ood_agg=aggregate(ood_rows)
    # Paired comparison of proposed controller vs each baseline.
    proposed_id=[r for r in id_rows if r.agent=="minimal_intervention"]
    proposed_ood=[r for r in ood_rows if r.agent=="minimal_intervention"]
    paired={}
    for name in BASELINES:
        if name=="minimal_intervention": continue
        paired[name]={
            "id_reward": paired_delta([r for r in id_rows if r.agent==name], proposed_id, "reward"),
            "id_progress": paired_delta([r for r in id_rows if r.agent==name], proposed_id, "progress_score"),
            "id_intervention_cost": paired_delta([r for r in id_rows if r.agent==name], proposed_id, "intervention_cost"),
            "id_catastrophe": paired_delta([r for r in id_rows if r.agent==name], proposed_id, "catastrophe_rate"),
            "ood_reward": paired_delta([r for r in ood_rows if r.agent==name], proposed_ood, "reward"),
            "ood_progress": paired_delta([r for r in ood_rows if r.agent==name], proposed_ood, "progress_score"),
        }
    result={
        "protocol":{
            "id_scenarios":len(id_s),"ood_scenarios":len(ood_s),
            "profiles":["local","regime","structural","adversarial","mixed"],
            "same_world_paired":True,
            "objective_metrics":["objective_completion","progress_score"],
            "minimal_intervention_definition":"lowest-cost feasible change from reference; switch only on strong local evidence",
            "baseline_note":"Representative architecture baselines, not claim-equivalent reimplementations of cited papers.",
        },
        "id":{"aggregate":id_agg,"metric_health":metric_health(id_rows),"pareto_frontier":pareto(id_agg)},
        "ood":{"aggregate":ood_agg,"metric_health":metric_health(ood_rows),"pareto_frontier":pareto(ood_agg)},
        "paired_vs_minimal":paired,
    }
    out="/mnt/data/trace_research_simulator_v0.9/results/minimal_intervention_benchmark_v2.json"
    with open(out,"w") as f: json.dump(result,f,indent=2)
    return result


if __name__=="__main__":
    print(json.dumps(run(),indent=2))
