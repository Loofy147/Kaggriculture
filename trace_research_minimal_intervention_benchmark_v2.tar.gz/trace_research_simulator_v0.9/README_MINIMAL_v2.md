# Minimal Intervention Benchmark v2

Run:

```bash
python minimal_intervention_benchmark_v2.py
```

Output:

`results/minimal_intervention_benchmark_v2.json`

The benchmark is intentionally separate from v1 and applies a common intervention-cost metric to every architecture.
